"""
align/sequence_align.py
~~~~~~~~~~~~~~~~~~~~~~~
Align block list A (original) với block list B (modified) thành list opcodes.

Fixes so với cũ:
1. HEADING SHIFT BUG
2. CROSS-MATCH BUG
3. _match_mixed_slice INDEX BUG
4. N-N table pairing
5. SIMILAR BLOCK DEDUP
6. EMPTY SHAPE CONTENT SIG
7. SHAPE WITH TEXT CONTENT SIG
8. MIXED SLICE OPCODE ORDER BUG
9. SHAPE IMAGE BUG
10. SHAPE SIMILARITY IMAGE BUG
11. MIXED SLICE DELETE/INSERT J/I BOUNDARY BUG (original fix, partially correct)
12. DELETE J COLLISION BUG — delete.j1 == replace.j1 → frontend nhầm delete thành replace.
    ROOT CAUSE: _j_insertion() tính j boundary dựa vào số ki < before_ki trong ki_to_kj,
    nhưng khi pair duy nhất có ki > tất cả unmatched ki (e.g. pair=(3,2) với ki=0,1,2 unmatched),
    j_ins = j1 + 0 = j1 cho tất cả delete → collision với replace.j1 = j1+kj_pair.
    Trường hợp tổng quát hơn: bất kỳ delete nào có next_pair.kj == paired_replace.j1 đều collision.
    FIX: tất cả delete emit với j1 == j2 == j2_slice (exclusive end của b_slice).
    j2_slice = j1 + b_len → luôn > max(replace.j1) = j1 + b_len - 1 → KHÔNG BAO GIỜ collision.
    insert giữ nguyên j đúng. replace giữ nguyên (i,j) đúng.
13. EQUAL INDEX SKEW — equal block có i1 != j1 bị đưa vào _match_mixed_slice không cần thiết.
    FIX: luôn emit equal trực tiếp, SequenceMatcher đã đảm bảo nội dung khớp.
14. N-N TABLE BRANCH RE-INTRODUCES BUG #12 — delete dùng j1+k thay vì j2 → collision.
    FIX: bỏ branch này, để _match_mixed_slice() xử lý (đã fix đúng).
"""

from __future__ import annotations

import difflib
import hashlib
from typing import List, Set, Tuple

from src.services.block.signature import _split_heading
from src.services.extractor.utils import norm_for_signature as _norm_text
from src.services.models.block import Block
from src.services.extractor.shape.shape_content import collect_shape_parts
from src.services.utils.shape_sig import stable_empty_shape_id

Opcode = Tuple[str, int, int, int, int]


# ══════════════════════════════════════════════════════════════════════════════
# Shape content helpers
# ══════════════════════════════════════════════════════════════════════════════

def _shape_combined(block: Block) -> str:
    parts = collect_shape_parts(block.node)
    return " ".join(parts)


def _count_content_parts(block: Block) -> int:
    return len(collect_shape_parts(block.node))


# ══════════════════════════════════════════════════════════════════════════════
# Heading context normalizer
# ══════════════════════════════════════════════════════════════════════════════

def _heading_ctx_body(heading_ctx: str) -> str:
    if not heading_ctx:
        return ""
    parts = heading_ctx.split(" > ")
    bodies = []
    for part in parts:
        _, body = _split_heading(part)
        bodies.append(body)
    return " > ".join(bodies)


# ══════════════════════════════════════════════════════════════════════════════
# Similarity
# ══════════════════════════════════════════════════════════════════════════════

def _block_similarity(a: Block, b: Block) -> float:
    if a.type != b.type:
        return 0.0

    same_heading = a.heading_ctx == b.heading_ctx

    if a.type == "shape":
        a_parts = collect_shape_parts(a.node)
        b_parts = collect_shape_parts(b.node)
        a_combined = " ".join(a_parts)
        b_combined = " ".join(b_parts)

        if not a_parts and not b_parts:
            return 0.45 if same_heading else 0.05

        if not a_parts or not b_parts:
            return 0.45 if same_heading else 0.0

        ratio = difflib.SequenceMatcher(
            a=a_combined, b=b_combined, autojunk=False
        ).ratio()
        heading_bonus = 0.2 if same_heading else 0.0
        return min(1.0, ratio + heading_bonus)

    if a.type == "table":
        a_lt = getattr(a.node, "logical_table", None)
        b_lt = getattr(b.node, "logical_table", None)
        if a_lt and b_lt:
            ratio = difflib.SequenceMatcher(
                None,
                a_lt.signature_list(),
                b_lt.signature_list(),
                autojunk=False,
            ).ratio()
        else:
            # fallback nếu chưa có logical_table
            a_text = (a.signature or "").strip()
            b_text = (b.signature or "").strip()
            ratio = difflib.SequenceMatcher(
                None, a_text, b_text, autojunk=False
            ).ratio()
        if same_heading:
            return max(0.5, ratio)
        return min(1.0, ratio + 0.15)

    # FIX #3: giảm heading_bonus để tránh pair paragraph khác nội dung
    # cùng heading vẫn vượt threshold (0.35 + ratio thấp = false replace)
    heading_bonus = 0.25 if same_heading else 0.05
    a_text = _norm_text(a.node.content.get("text", ""))
    b_text = _norm_text(b.node.content.get("text", ""))
    ratio = difflib.SequenceMatcher(a=a_text, b=b_text, autojunk=False).ratio()
    return min(1.0, ratio + heading_bonus)


# ══════════════════════════════════════════════════════════════════════════════
# Content-only signature
# ══════════════════════════════════════════════════════════════════════════════

def _content_sig(block: Block) -> str:
    t = block.type

    if t == "shape":
        parts    = collect_shape_parts(block.node)
        combined = " ".join(parts)
        ctx_body = _heading_ctx_body(block.heading_ctx or "")

        if not parts:
            sid = stable_empty_shape_id(
                uid=getattr(block.node, "uid", None),
                parent_uid=getattr(block.node, "parent_uid", None),
                heading_ctx=ctx_body,
            )
            return f"shape|empty|{sid}|{ctx_body}"

        h          = hashlib.md5(combined.encode("utf-8")).hexdigest()[:16]
        part_count = len(parts)
        return f"shape|{h}|n{part_count}|{ctx_body}"

    if t == "heading":
        level = int(block.node.content.get("level", 1) or 1)
        txt   = _norm_text(block.node.content.get("text", ""))
        chapter, body = _split_heading(txt)
        chapter_depth = len(chapter.split(".")) if chapter else 0
        h = hashlib.md5(body.encode("utf-8")).hexdigest()[:12]
        return f"H{level}|d{chapter_depth}|{h}"

    return f"{t}|{block.signature or ''}"


# ══════════════════════════════════════════════════════════════════════════════
# Opcode sort key
# ══════════════════════════════════════════════════════════════════════════════

def _opcode_sort_key(op: Opcode) -> tuple:
    tag, i1, i2, j1, j2 = op
    return (i1, j1)


# ══════════════════════════════════════════════════════════════════════════════
# Main aligner
# ══════════════════════════════════════════════════════════════════════════════

def align_blocks(a_blocks: List[Block], b_blocks: List[Block]) -> List[Opcode]:
    a_sigs = [_content_sig(b) for b in a_blocks]
    b_sigs = [_content_sig(b) for b in b_blocks]

    sm = difflib.SequenceMatcher(a=a_sigs, b=b_sigs, autojunk=False)
    raw_opcodes = sm.get_opcodes()
    refined: List[Opcode] = []

    for tag, i1, i2, j1, j2 in raw_opcodes:
        # FIX #13: equal luôn emit trực tiếp — SequenceMatcher đã đảm bảo
        # nội dung khớp, index lệch (i1 != j1) là bình thường khi có
        # insert/delete trước đó. Không cần _match_mixed_slice.
        if tag == "equal":
            refined.append((tag, i1, i2, j1, j2))
            continue

        if tag != "replace":
            refined.append((tag, i1, i2, j1, j2))
            continue

        a_slice = a_blocks[i1:i2]
        b_slice = b_blocks[j1:j2]

        if len(a_slice) == 1 and len(b_slice) == 1:
            similarity = _block_similarity(a_slice[0], b_slice[0])
            threshold = _similarity_threshold(a_slice[0].type)

            if similarity >= threshold:
                refined.append(("replace", i1, i2, j1, j2))
            else:
                refined.append(("delete", i1, i2, j1, j1))
                refined.append(("insert", i2, i2, j1, j2))
            continue

        # FIX #14: bỏ branch N-N table pair theo vị trí.
        # Branch cũ tái tạo lại bug #12 (delete dùng j1+k thay vì j2 → collision).
        # _match_mixed_slice() xử lý đúng hơn: exact match trước, greedy sau,
        # và delete luôn emit j2 đúng.

        if len(a_slice) > 0 and len(b_slice) > 0:
            _match_mixed_slice(refined, a_blocks, b_blocks, i1, i2, j1, j2)
            continue

        refined.append((tag, i1, i2, j1, j2))

    refined.sort(key=_opcode_sort_key)
    return refined


def _similarity_threshold(block_type: str) -> float:
    """
    Threshold fuzzy match theo block type.

    paragraph/heading:
        Cho phép khác nhẹ vẫn replace
        tránh delete + insert quá nhiều.

    shape:
        Khá strict vì shape dễ match nhầm.

    table:
        Strict hơn để tránh pair nhầm bảng.
    """
    if block_type == "heading":
        return 0.72

    if block_type == "paragraph":
        return 0.68

    if block_type == "shape":
        return 0.80

    if block_type == "table":
        return 0.82

    return 0.75


def _match_mixed_slice(
    refined: List[Opcode],
    a_blocks: List[Block],
    b_blocks: List[Block],
    i1: int, i2: int,
    j1: int, j2: int,
) -> None:
    a_slice = a_blocks[i1:i2]
    b_slice = b_blocks[j1:j2]

    matched_a: Set[int] = set()
    matched_b: Set[int] = set()
    pairs: List[Tuple[int, int]] = []

    # ── Bước 1: exact match theo thứ tự vị trí ───────────────────────────
    # Dùng SequenceMatcher trên sub-slice để tìm exact match đúng thứ tự
    # thay vì nested loop first-found (sai với duplicate)
    a_sigs = [_content_sig(a) for a in a_slice]
    b_sigs = [_content_sig(b) for b in b_slice]

    sub_sm = difflib.SequenceMatcher(a=a_sigs, b=b_sigs, autojunk=False)
    for sub_tag, si1, si2, sj1, sj2 in sub_sm.get_opcodes():
        if sub_tag != "equal":
            continue
        for offset in range(si2 - si1):
            ki = si1 + offset
            kj = sj1 + offset
            if ki not in matched_a and kj not in matched_b:
                matched_a.add(ki)
                matched_b.add(kj)
                pairs.append((ki, kj))

    # ── Bước 2: greedy similarity cho phần còn lại ───────────────────────
    candidates: List[Tuple[float, int, int]] = []

    for ki, a in enumerate(a_slice):
        if ki in matched_a:
            continue

        threshold = _similarity_threshold(a.type)

        for kj, b in enumerate(b_slice):
            if kj in matched_b:
                continue

            sim = _block_similarity(a, b)

            if sim >= threshold:
                candidates.append((sim, ki, kj))

    candidates.sort(key=lambda item: (-item[0], abs(item[1] - item[2]), item[1], item[2]))

    for sim, ki, kj in candidates:
        if ki in matched_a or kj in matched_b:
            continue
        matched_a.add(ki)
        matched_b.add(kj)
        pairs.append((ki, kj))

    # ── Emit opcodes ──────────────────────────────────────────────────────
    pair_by_ki = {ki: kj for ki, kj in pairs}
    paired_kj = set(pair_by_ki.values())

    for ki in range(len(a_slice)):
        ai = i1 + ki
        if ki in pair_by_ki:
            kj = pair_by_ki[ki]
            bj = j1 + kj
            a_sig = _content_sig(a_slice[ki])
            b_sig = _content_sig(b_slice[kj])
            if a_sig == b_sig:
                refined.append(("equal", ai, ai + 1, bj, bj + 1))
            else:
                refined.append(("replace", ai, ai + 1, bj, bj + 1))
        else:
            # delete: j1 == j2 == j2_slice để tránh collision với replace (fix #12)
            refined.append(("delete", ai, ai + 1, j2, j2))

    for kj in sorted(kj for kj in range(len(b_slice)) if kj not in paired_kj):
        refined.append(("insert", i2, i2, j1 + kj, j1 + kj + 1))
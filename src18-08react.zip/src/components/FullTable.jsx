﻿// ─────────────────────────────────────────────────────────────
// FullTable.jsx
// ─────────────────────────────────────────────────────────────
import { CellContent, CellNode } from './CellContent';

export function FullTable({
    tableData,
    label = 'before',
    tableChanges = [],
    structureChanged = false,
}) {
    if (!tableData) {
        return <div className="empty-hint" style={{ padding: 8 }}>(không có)</div>;
    }

    const { total_rows, total_cols, cells = [] } = tableData;
    const side = label === 'before' ? 'left' : label === 'after' ? 'right' : 'left';

    const addedRows = new Set();
    const deletedRows = new Set();
    const modifiedRows = new Set();
    const cellChangeMap = {};
    const deletedCols = {};
    const addedCols = {};

    tableChanges.forEach(c => {
        const ar = c.anchor_row;

        if (c.type === 'table_row_deleted') deletedRows.add(ar);
        if (c.type === 'table_row_added') addedRows.add(ar);
        if (c.type === 'table_row_modified') {
            modifiedRows.add(ar);
            if (!structureChanged) {
                (c.cell_changes || []).forEach(cc => {
                    const ac = cc.anchor_col;
                    if (['table_cell_modified', 'table_cell_span_changed'].includes(cc.type)) {
                        cellChangeMap[`${ar}_${ac}`] = cc;
                    }
                    if (cc.type === 'table_cell_deleted') {
                        if (!deletedCols[ar]) deletedCols[ar] = new Set();
                        deletedCols[ar].add(ac);
                    }
                    if (cc.type === 'table_cell_added') {
                        if (!addedCols[ar]) addedCols[ar] = new Set();
                        addedCols[ar].add(ac);
                    }
                });
            }
        }
    });

    const gridStyle = {
        display: 'grid',
        gridTemplateColumns: `repeat(${total_cols}, minmax(0, 1fr))`,
        gridTemplateRows: `repeat(${total_rows}, auto)`,
        border: '0.5px solid var(--color-border-secondary)',
        borderRadius: 'var(--border-radius-md)',
        overflow: 'hidden',
        fontSize: 13,
        lineHeight: 1.5,
    };

    return (
        <div className="tbl-wrap">
            <div style={gridStyle}>
                {cells.map(cell => {
                    const { uid, anchor_row, anchor_col, row_span, col_span } = cell;
                    const key = `${anchor_row}_${anchor_col}`;
                    const cc = cellChangeMap[key];

                    const rowCls =
                        (label === 'after' && addedRows.has(anchor_row)) ? 'row-added' :
                            (label === 'before' && deletedRows.has(anchor_row)) ? 'row-deleted' :
                                modifiedRows.has(anchor_row) ? 'row-modified' : '';

                    const cellCls = cc
                        ? 'cell-changed'
                        : (label === 'before' && deletedCols[anchor_row]?.has(anchor_col))
                            ? 'cell-deleted'
                            : (label === 'after' && addedCols[anchor_row]?.has(anchor_col))
                                ? 'cell-added'
                                : rowCls;

                    const cellStyle = {
                        gridColumn: `${anchor_col + 1} / span ${col_span}`,
                        gridRow: `${anchor_row + 1} / span ${row_span}`,
                        padding: '4px 8px',
                        border: '0.5px solid var(--color-border-tertiary)',
                        wordBreak: 'break-word',
                        minHeight: 28,
                    };

                    return (
                        <div
                            key={uid || key}
                            className={cellCls}
                            style={cellStyle}
                        >
                            {cc
                                ? <CellContent cellChange={cc} side={side} cell={cell} />
                                : <CellNode cell={cell} />
                            }
                        </div>
                    );
                })}
            </div>
        </div>
    );
}
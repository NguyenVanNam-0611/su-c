// ─────────────────────────────────────────────────────────────
// renderers/ImageChange.jsx
// ─────────────────────────────────────────────────────────────
import { MetaRow } from '../WordDiff';

export function ImageChange({ change }) {
    const imgChange = change.image_change || {};
    const leftImg = change.left_img || imgChange.left_img || change.left || null;
    const rightImg = change.right_img || imgChange.right_img || change.right || null;
    const kind = change.change_kind || 'replace';

    const leftUrl = getImageUrl(leftImg);
    const rightUrl = getImageUrl(rightImg);

    const leftAlt = getImageAlt(leftImg, 'ảnh gốc');
    const rightAlt = getImageAlt(rightImg, 'ảnh mới');

    const leftFallback = kind === 'insert'
        ? '(chưa tồn tại)'
        : '(không có)';

    const rightFallback = kind === 'delete'
        ? '(đã xóa)'
        : '(không có)';

    return (
        <>
            <div className="change-cell left">
                <MetaRow change={change} side="left" />
                <ImgSlot url={leftUrl} alt={leftAlt} fallback={leftFallback} />
            </div>

            <div className="change-cell right">
                <MetaRow change={change} side="right" />
                <ImgSlot url={rightUrl} alt={rightAlt} fallback={rightFallback} />
            </div>
        </>
    );
}

function getImageUrl(img) {
    return (
        img?.image_url
        || img?.image?.image_url
        || img?.content?.image_url

        || img?.node?.image_url
        || img?.node?.image?.image_url
        || img?.node?.content?.image_url

        || img?.node?.children?.find?.(c => c?.type === 'image')?.image_url
        || img?.node?.children?.find?.(c => c?.type === 'image')?.image?.image_url
        || img?.node?.children?.find?.(c => c?.type === 'image')?.content?.image_url

        || null
    );
}

function getImageAlt(img, fallback) {
    return (
        img?.image?.name
        || img?.caption
        || img?.content?.alt_text
        || img?.node?.content?.alt_text
        || fallback
    );
}

function ImgSlot({ url, alt, fallback }) {
    if (!url) {
        return (
            <div className="img-box">
                <div className="img-none">{fallback}</div>
            </div>
        );
    }

    return (
        <div className="img-box">
            <img
                src={url}
                alt={alt}
                style={{
                    maxWidth: '100%',
                    maxHeight: 520,
                    objectFit: 'contain',
                    display: 'block',
                }}
            />
        </div>
    );
}
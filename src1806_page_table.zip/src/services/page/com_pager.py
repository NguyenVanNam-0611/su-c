"""
page/com_pager.py
~~~~~~~~~~~~~~~~~
Dùng Word COM để lấy page thật theo index trực tiếp.

Chiến lược chuẩn:
- paragraph/heading : doc.Paragraphs(idx).Range -> page
- table             : doc.Tables(idx).Range -> page_start/page_end
- shape             : doc.Shapes(...).Anchor -> page
- image             : không lấy riêng, inherit từ parent ở page_injector

Không lấy page row/cell/nested table để tránh sai với merged/nested table
và tránh chậm/crash COM.
"""
from __future__ import annotations

import logging
import os
import sys
from typing import Any, Dict, List, Tuple

logger = logging.getLogger(__name__)

_WD_ACTIVE_END_PAGE_NUMBER = 3
_WD_COLLAPSE_START = 1
_WD_COLLAPSE_END = 0


PageInfo = Dict[str, int]
PageMap = Dict[str, PageInfo]


def get_pages_via_com_index(
    docx_path: str,
    uid_index_pairs: List[Tuple[str, str, Any]],
) -> PageMap:
    """
    Lấy page number bằng COM index trực tiếp.

    Input:
        uid_index_pairs: List[(uid, obj_type, idx_or_id)]
            obj_type = "para"  -> idx là int, dùng doc.Paragraphs(idx)
            obj_type = "table" -> idx là int, dùng doc.Tables(idx)
            obj_type = "shape" -> idx/id/name, dùng doc.Shapes map

    Output:
        {
            uid_para:  {"page": 1, "page_start": 1, "page_end": 1},
            uid_table: {"page": 2, "page_start": 2, "page_end": 3},
            uid_shape: {"page": 4, "page_start": 4, "page_end": 4},
        }
    """
    if sys.platform != "win32":
        logger.warning("[COM] Không phải Windows — bỏ qua COM pager.")
        return {}

    if not uid_index_pairs:
        return {}

    try:
        import pythoncom
        import win32com.client  # noqa: F401
    except ImportError:
        logger.warning("[COM] pywin32 chưa cài — bỏ qua COM pager.")
        return {}

    abs_path = os.path.normpath(os.path.abspath(str(docx_path)))

    if not os.path.exists(abs_path):
        logger.error(f"[COM] File không tồn tại: {abs_path}")
        return {}

    word = None
    doc = None
    result: PageMap = {}
    com_initialized = False

    try:
        pythoncom.CoInitializeEx(pythoncom.COINIT_APARTMENTTHREADED)
        com_initialized = True

        import win32com.client

        word = win32com.client.DispatchEx("Word.Application")
        word.Visible = False
        word.DisplayAlerts = 0

        doc = word.Documents.Open(
            abs_path,
            ReadOnly=True,
            AddToRecentFiles=False,
            ConfirmConversions=False,
        )

        try:
            doc.Repaginate()
        except Exception:
            pass

        para_count = int(doc.Paragraphs.Count)
        table_count = int(doc.Tables.Count)
        shape_count = int(doc.Shapes.Count)

        shape_id_map = _build_shape_id_map(doc, shape_count)

        for uid, obj_type, idx_or_id in uid_index_pairs:
            try:
                if obj_type == "para":
                    idx = int(idx_or_id)
                    if idx < 1 or idx > para_count:
                        logger.debug(
                            f"[COM] para idx={idx} out of range max={para_count}"
                        )
                        continue

                    rng = doc.Paragraphs(idx).Range
                    page = _page_of_range_start(rng)
                    if page:
                        result[uid] = {
                            "page": page,
                            "page_start": page,
                            "page_end": page,
                        }

                elif obj_type == "table":
                    idx = int(idx_or_id)
                    if idx < 1 or idx > table_count:
                        logger.debug(
                            f"[COM] table idx={idx} out of range max={table_count}"
                        )
                        continue

                    tbl = doc.Tables(idx)
                    page_start, page_end = _page_range_of_table(tbl)

                    if page_start:
                        if not page_end:
                            page_end = page_start

                        if page_end < page_start:
                            page_end = page_start

                        result[uid] = {
                            "page": page_start,
                            "page_start": page_start,
                            "page_end": page_end,
                        }

                elif obj_type == "shape":
                    com_idx = shape_id_map.get(str(idx_or_id))
                    if com_idx is None:
                        logger.debug(f"[COM] shape id/name={idx_or_id} không tìm thấy")
                        continue

                    shp = doc.Shapes(com_idx)
                    rng = shp.Anchor
                    page = _page_of_range_start(rng)

                    if page:
                        result[uid] = {
                            "page": page,
                            "page_start": page,
                            "page_end": page,
                        }

                else:
                    continue

            except Exception as e:
                logger.debug(
                    f"[COM] uid={uid} obj_type={obj_type} idx={idx_or_id} failed: {e}"
                )
                continue

    except Exception as e:
        logger.error(f"[COM] Word COM error: {e}")

    finally:
        try:
            if doc is not None:
                doc.Close(False)
        except Exception:
            pass

        try:
            if word is not None:
                word.Quit()
        except Exception:
            pass

        if com_initialized:
            try:
                pythoncom.CoUninitialize()
            except Exception:
                pass

    logger.info(
        f"[COM] Index-based: lấy page cho {len(result)}/{len(uid_index_pairs)} blocks."
    )
    return result


def _build_shape_id_map(doc, shape_count: int) -> Dict[str, int]:
    """
    Build map để tìm shape theo ID hoặc Name.
    """
    shape_id_map: Dict[str, int] = {}

    for si in range(1, shape_count + 1):
        try:
            shp = doc.Shapes(si)

            sid_num = str(shp.ID)
            sid_name = str(shp.Name)

            if sid_num:
                shape_id_map[sid_num] = si
            if sid_name:
                shape_id_map[sid_name] = si

        except Exception:
            continue

    return shape_id_map


def _page_of_range_start(rng) -> int | None:
    """
    Lấy page tại đầu range.
    """
    if rng is None:
        return None

    try:
        dup = rng.Duplicate
        dup.Collapse(_WD_COLLAPSE_START)
        return int(dup.Information(_WD_ACTIVE_END_PAGE_NUMBER))
    except Exception:
        try:
            return int(rng.Information(_WD_ACTIVE_END_PAGE_NUMBER))
        except Exception:
            return None


def _page_of_range_end(rng) -> int | None:
    """
    Lấy page tại cuối range.

    Với Word table.Range, CollapseEnd có thể rơi ra sau bảng.
    Vì vậy lùi End lại 1 character trước khi collapse để lấy page
    của nội dung cuối cùng thuộc bảng.
    """
    if rng is None:
        return None

    try:
        dup = rng.Duplicate

        # Tránh lấy page của paragraph ngay sau bảng.
        if dup.End > dup.Start:
            dup.End = dup.End - 1

        dup.Collapse(_WD_COLLAPSE_END)
        return int(dup.Information(_WD_ACTIVE_END_PAGE_NUMBER))

    except Exception:
        try:
            return int(rng.Information(_WD_ACTIVE_END_PAGE_NUMBER))
        except Exception:
            return None


def _page_range_of_table(tbl) -> Tuple[int | None, int | None]:
    """
    Table chỉ lấy page_start/page_end của Range bảng.

    Không gọi Row.Range/Cell.Range.
    """
    try:
        rng = tbl.Range
    except Exception:
        return None, None

    page_start = _page_of_range_start(rng)
    page_end = _page_of_range_end(rng)

    return page_start, page_end
"""
models/block.py
~~~~~~~~~~~~~~~
Block là wrapper phẳng của DocNode, dùng cho bước align và diff.

Mỗi Block đại diện cho 1 đơn vị so sánh ở document level:
    - heading
    - paragraph
    - image
    - shape
    - table     ← diff nội dung bên trong do TableDiff xử lý riêng

KHÔNG tạo Block cho: row, cell (chỉ tồn tại bên trong TableDiff)

block_builder.py chịu trách nhiệm duyệt DocNode tree và tạo List[Block].
Block không tự tính signature — signature được inject từ signature.py.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

from src.services.models.docnode import DocNode

BlockType = str

BLOCK_TYPES: frozenset[str] = frozenset({
    "heading",
    "paragraph",
    "image",
    "shape",
    "table",
})


@dataclass
class Block:
    type: BlockType
    node: DocNode

    # inject từ signature.py sau khi build
    signature: str = ""

    # inject từ block_builder sau khi duyệt cây
    heading_ctx: Optional[str] = None
    heading_level: int = 0

    # auto-fill từ node trong __post_init__
    uid: Optional[str] = None
    parent_uid: Optional[str] = None
    path: Optional[str] = None
    order: int = 0

    # flags — tính từ type
    is_heading:   bool = field(default=False, init=False)
    is_paragraph: bool = field(default=False, init=False)
    is_image:     bool = field(default=False, init=False)
    is_shape:     bool = field(default=False, init=False)
    is_table:     bool = field(default=False, init=False)

    # text ngắn cho log / debug
    preview_text: str = field(default="", init=False)

    # ── Init ──────────────────────────────────────────────────────────────────

    def __post_init__(self) -> None:
        if not isinstance(self.node, DocNode):
            raise TypeError(f"Block.node must be DocNode, got {type(self.node)}")
        if self.type not in BLOCK_TYPES:
            raise ValueError(
                f"Block.type {self.type!r} không hợp lệ. "
                f"Hợp lệ: {sorted(BLOCK_TYPES)}"
            )

        # Fill từ node
        if self.uid is None:
            self.uid = self.node.uid
        if self.parent_uid is None:
            self.parent_uid = self.node.parent_uid
        if self.path is None:
            self.path = self.node.path
        if self.order == 0 and self.node.order != 0:
            self.order = self.node.order

        # Flags
        self.is_heading   = self.type == "heading"
        self.is_paragraph = self.type == "paragraph"
        self.is_image     = self.type == "image"
        self.is_shape     = self.type == "shape"
        self.is_table     = self.type == "table"

        self.preview_text = self._build_preview()

    def _build_preview(self) -> str:
        content = self.node.content

        if self.type in ("heading", "paragraph"):
            text = content.get("text") or ""

        elif self.type == "image":
            alt = content.get("alt_text") or ""
            text = f"[IMAGE: {alt}]" if alt else "[IMAGE]"

        elif self.type == "shape":
            para = next(
                (c for c in self.node.children if c.type == "paragraph"),
                None,
            )
            inner = (para.content.get("text") or "") if para else ""
            text = f"[SHAPE: {inner}]" if inner else "[SHAPE]"

        elif self.type == "table":
            lt = self.node.logical_table
            if lt is not None:
                # logical_table đã được build — dùng số liệu chính xác
                text = f"[TABLE {lt.total_rows}×{lt.total_cols}]"
            else:
                # fallback: đếm từ DocNode tree (trước khi extractor chạy)
                rows = self.node.children
                n_rows = len(rows)
                n_cols = len(rows[0].children) if rows else 0
                text = f"[TABLE {n_rows}×{n_cols}]"

        else:
            text = ""

        return text[:200].strip()

    # ── Helpers ───────────────────────────────────────────────────────────────

    def get_text(self) -> str:
        """
        Text đầy đủ, đúng nguồn theo từng type.
        Với table: trả về toàn bộ text cells (normalized) nối nhau —
        dùng cho signature hoặc full-text search, không phải display.
        """
        if self.type in ("heading", "paragraph"):
            return self.node.content.get("text") or ""

        if self.type == "shape":
            return " ".join(
                c.content.get("text") or ""
                for c in self.node.children
                if c.type == "paragraph"
            )

        if self.type == "table":
            lt = self.node.logical_table
            if lt is not None:
                return " ".join(c.text for c in lt.cells if c.text)
            # fallback: extract text từ DocNode tree
            return " ".join(
                cell.content.get("text") or ""
                for cell in self.node.find_without_nested_tables("cell")
            )

        # image — không có text đại diện
        return ""


    def get_runs(self) -> List[dict]:
        """Runs của paragraph / heading (cho diff inline)."""
        return self.node.content.get("runs") or []

    def has_children(self) -> bool:
        return len(self.node.children) > 0

    def get_logical_table(self):
        """
        Trả về LogicalTable nếu node là table đã qua extractor.
        Trả về None nếu chưa có (vd: block được tạo trước khi extract).
        """
        return self.node.logical_table

    # ── Equality ──────────────────────────────────────────────────────────────

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Block):
            return NotImplemented
        if self.signature and other.signature:
            return self.signature == other.signature
        return self.uid == other.uid

    def __hash__(self) -> int:
        return hash(self.signature or self.uid)

    # ── Debug ─────────────────────────────────────────────────────────────────

    def __repr__(self) -> str:
        return (
            f"Block("
            f"type={self.type!r}, "
            f"uid={self.uid!r}, "
            f"order={self.order}, "
            f"heading_ctx={self.heading_ctx!r}, "
            f"preview={self.preview_text!r}"
            f")"
        )
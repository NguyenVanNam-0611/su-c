import os
import time
import pythoncom
import win32com.client

WD_FORMAT_XML_DOCUMENT = 16

def convert_doc_to_docx_if_needed(file_path: str) -> str:
    ext = os.path.splitext(file_path)[1].lower()

    if ext != ".doc":
        return file_path

    abs_path = os.path.normpath(os.path.abspath(file_path))

    docx_path = os.path.normpath(
        os.path.splitext(abs_path)[0] + ".docx"
    )

    word = None
    doc = None

    pythoncom.CoInitializeEx(
        pythoncom.COINIT_APARTMENTTHREADED
    )

    try:
        word = win32com.client.DispatchEx("Word.Application")

        word.Visible = False
        word.DisplayAlerts = 0

        try:
            word.AutomationSecurity = 3
        except Exception:
            pass

        doc = word.Documents.Open(
            abs_path,
            ReadOnly=True,
            AddToRecentFiles=False,
        )

        doc.SaveAs(
            docx_path,
            FileFormat=WD_FORMAT_XML_DOCUMENT,
        )

        doc.Close(SaveChanges=False)
        doc = None

        for _ in range(20):
            if os.path.exists(docx_path):
                break
            time.sleep(0.1)

        return docx_path

    finally:
        try:
            if doc is not None:
                doc.Close(SaveChanges=False)
        except Exception:
            pass

        try:
            if word is not None:
                word.Quit()
        except Exception:
            pass

        pythoncom.CoUninitialize()
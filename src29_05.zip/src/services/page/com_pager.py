"""
page/com_pager.py
~~~~~~~~~~~~~~~~~
Dùng Word COM để lấy page thật cho từng block uid.

Input : docx_path + danh sách (uid, search_text)
Output: dict[uid → page_number]

Chạy trên Windows, cần Word cài sẵn.
Fallback: trả {} nếu COM không khả dụng (Linux/Docker).
"""
from __future__ import annotations

import logging
import sys
from typing import Dict, List, Tuple

logger = logging.getLogger(__name__)

# wdCollapseStart, wdActiveEndPageNumber
_WD_COLLAPSE_START        = 1
_WD_ACTIVE_END_PAGE_NUMBER = 3
_WD_FIND_CONTINUE         = 1


def get_pages_via_com(
    docx_path: str,
    uid_text_pairs: List[Tuple[str, str]],  # [(uid, search_text), ...]
) -> Dict[str, int]:
    """
    Mở docx bằng Word COM, tìm từng search_text,
    lấy page number, trả dict {uid: page}.

    uid_text_pairs: list các (uid, text) — text là nội dung
                    để Find trong Word. Với table dùng text
                    của cell đầu tiên.
    """
    if sys.platform != "win32":
        logger.warning("[COM] Không phải Windows — bỏ qua COM pager.")
        return {}

    if not uid_text_pairs:
        return {}

    try:
        import win32com.client
    except ImportError:
        logger.warning("[COM] pywin32 chưa cài — bỏ qua COM pager.")
        return {}

    word = None
    doc  = None
    result: Dict[str, int] = {}

    try:
        word         = win32com.client.Dispatch("Word.Application")
        word.Visible = False
        doc          = word.Documents.Open(str(docx_path))

        for uid, search_text in uid_text_pairs:
            if not search_text or not search_text.strip():
                continue

            try:
                page = _find_page(doc, search_text.strip()[:100])
                if page:
                    result[uid] = page
            except Exception as e:
                logger.debug(f"[COM] uid={uid} find failed: {e}")
                continue

    except Exception as e:
        logger.error(f"[COM] Word COM error: {e}")

    finally:
        try:
            if doc:
                doc.Close(False)
        except Exception:
            pass
        try:
            if word:
                word.Quit()
        except Exception:
            pass

    logger.info(f"[COM] Lấy page cho {len(result)}/{len(uid_text_pairs)} blocks.")
    return result


def _find_page(doc, text: str) -> int | None:
    """
    Tìm text trong doc, lấy page của vị trí đầu tiên tìm thấy.
    """
    rng = doc.Content
    rng.Find.ClearFormatting()

    found = rng.Find.Execute(
        FindText=text,
        MatchCase=False,
        MatchWholeWord=False,
        Forward=True,
    )

    if not found:
        return None

    # Collapse về đầu range → lấy start_page
    rng.Collapse(_WD_COLLAPSE_START)
    return int(rng.Information(_WD_ACTIVE_END_PAGE_NUMBER))
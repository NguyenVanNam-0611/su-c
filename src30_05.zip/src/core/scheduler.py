"""
core/scheduler.py
~~~~~~~~~~~~~~~~~
APScheduler singleton — quản lý:
  1. Purge job DB cũ mỗi 24h
  2. Cleanup file upload sau 24h (schedule_cleanup)
  3. Cleanup ảnh tmp /tmp/docx_images mỗi 12h (cleanup_old_images)

Tách ra khỏi api/upload.py vì scheduler là infrastructure concern,
không phải API concern. main.py import trực tiếp từ đây.

Public API:
    start_scheduler()
    stop_scheduler()
    schedule_cleanup(job_id, folders)
    delete_upload_files(job_id, folders)   ← gọi bởi APScheduler
"""

from __future__ import annotations

import logging
import shutil
from datetime import datetime, timedelta, timezone
from pathlib import Path

from apscheduler.jobstores.sqlalchemy import SQLAlchemyJobStore
from apscheduler.schedulers.asyncio import AsyncIOScheduler

from src.core.jobs import mark_job_files_deleted, purge_old_jobs
from src.services.utils.image_store import cleanup_old_images

logger = logging.getLogger(__name__)

# ── Scheduler singleton ───────────────────────────────────────────────────────

_jobstore_path = Path("data/scheduler.db")
_jobstore_path.parent.mkdir(parents=True, exist_ok=True)

scheduler = AsyncIOScheduler(
    jobstores={
        "default": SQLAlchemyJobStore(url=f"sqlite:///{_jobstore_path}")
    },
    timezone="UTC",
)


# ── Purge task ────────────────────────────────────────────────────────────────

def _purge_old_jobs_task() -> None:
    """
    Xóa record DB của các job cũ hơn 24h đã done/error.
    Chạy định kỳ mỗi 24h, persist vào SQLite jobstore.
    misfire_grace_time=3600 đảm bảo chạy bù trong vòng 1h sau restart.
    """
    deleted = purge_old_jobs(older_than_hours=24)
    if deleted:
        logger.info(f"[PURGE] Deleted {deleted} old job record(s) from DB")
    else:
        logger.debug("[PURGE] No old job records to delete")


# ── Image tmp cleanup task ────────────────────────────────────────────────────

def _cleanup_images_task() -> None:
    """
    Xóa ảnh trong /tmp/docx_images cũ hơn 12h.
    Chạy định kỳ mỗi 12h — khớp với MAX_AGE_HOURS trong image_store.py.

    Không persist vào SQLite jobstore (in-memory job) vì:
      - Không cần chạy bù sau restart — ảnh cũ sẽ bị dọn ở lần chạy tiếp theo
      - Tránh accumulate stale date-trigger records trong jobstore
    """
    deleted = cleanup_old_images()
    if deleted:
        logger.info(f"[IMAGE_CLEANUP] Deleted {deleted} stale image file(s)")
    else:
        logger.debug("[IMAGE_CLEANUP] No stale images to delete")


# ── Lifecycle ─────────────────────────────────────────────────────────────────

def start_scheduler() -> None:
    if not scheduler.running:
        scheduler.start()

        scheduler.add_job(
            _purge_old_jobs_task,
            trigger="interval",
            hours=24,
            id="purge_old_jobs",
            replace_existing=True,
            misfire_grace_time=3600,
        )

        # Image cleanup — jobstore="memory" để không persist, không cần chạy bù
        scheduler.add_job(
            _cleanup_images_task,
            trigger="interval",
            hours=12,
            id="cleanup_images",
            replace_existing=True,
            misfire_grace_time=None,
            jobstore="default",
        )

        logger.info("[SCHEDULER] Started with SQLite jobstore")


def stop_scheduler() -> None:
    if scheduler.running:
        scheduler.shutdown(wait=False)
        logger.info("[SCHEDULER] Stopped")


# ── File cleanup ──────────────────────────────────────────────────────────────

def delete_upload_files(job_id: str, folders: list[str]) -> None:
    """
    Xóa các folder upload của job.
    Được gọi bởi APScheduler sau 24h — chạy trong thread pool của scheduler.
    """
    for folder in folders:
        try:
            p = Path(folder)
            if p.exists():
                shutil.rmtree(p)
                logger.info(f"[CLEANUP] Deleted: {folder}")
            else:
                logger.warning(f"[CLEANUP] Already gone: {folder}")
        except Exception as e:
            logger.error(f"[CLEANUP] Failed to delete {folder}: {e}")

    try:
        mark_job_files_deleted(job_id)
    except Exception as e:
        logger.error(f"[CLEANUP] Failed to update DB for job {job_id}: {e}")


def schedule_cleanup(job_id: str, folders: list[Path]) -> None:
    """
    Lên lịch xóa file upload sau 24h.
    Persist vào SQLite jobstore → tự chạy bù sau restart.
    misfire_grace_time=None: chạy dù trễ bao lâu (không bỏ qua).
    """
    run_at = datetime.now(timezone.utc) + timedelta(hours=24)
    scheduler.add_job(
        delete_upload_files,
        trigger="date",
        run_date=run_at,
        args=[job_id, [str(f) for f in folders]],
        id=f"cleanup_{job_id}",
        replace_existing=True,
        misfire_grace_time=None,
    )
    logger.info(f"[CLEANUP] Scheduled for job {job_id} at {run_at.isoformat()}")
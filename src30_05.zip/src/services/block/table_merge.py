"""
block/table_merge.py
~~~~~~~~~~~~~~~~~~~~
Merge các bảng bị cắt trang thành 1 bảng liên tục.

Tách từ block_builder.py.
Import bởi: block_builder.py

THAY ĐỔI so với version cũ:
    1. content_blocks được copy đầy đủ khi merge (fix mất nội dung)
    2. skip_count tính động từ header comparison (fix offset -1 cứng sai)
    3. Bỏ điều kiện heading_ctx strict (fix miss case bảng layout nhiều trang)
    4. total_rows recalculate từ cells thực tế sau merge (fix count lệch)
    5. _merge_two_tables truyền flag has_repeated_header xuống (rõ ràng hơn)
    6. Bỏ check col_count trong _can_merge:
       header key match + continuation marker đã đủ chặt,
       col_count dễ bị lệch do subheader/gridSpan khác nhau giữa 2 trang.
    7. _normalize_col_span: fix cell cuối bảng extra bị hụt col_span
       khi grid của extra ít hơn grid của base (do subheader).
"""

from __future__ import annotations

from typing import List, Optional

from src.services.models.docnode import DocNode
from src.services.models.block import Block
from src.services.models.logical_table import LogicalCell, LogicalTable
from src.services.block.signature import signature
from src.services.block.filters import _norm, _is_skip_pattern


# ══════════════════════════════════════════════════════════════════════════════
# LogicalTable helpers
# ══════════════════════════════════════════════════════════════════════════════

def _get_logical_table(table_node: DocNode) -> Optional[LogicalTable]:
    return getattr(table_node, "logical_table", None)


def _get_header_key(table_node: DocNode) -> Optional[str]:
    """
    Lấy key từ anchor_row=0 (hàng đầu tiên).
    Header toàn rỗng → không đủ tin cậy để match → trả None.
    """
    lt = _get_logical_table(table_node)
    if lt is None:
        return None
    header_cells = lt.cells_in_row(0)
    if not header_cells:
        return None
    key = "|".join(_norm(c.text) for c in header_cells)
    if not key.replace("|", "").strip():
        return None
    return key


def _last_anchor_row_is_continue(table_node: DocNode) -> bool:
    """
    Hàng anchor cuối cùng toàn là text kiểu "tiếp trang sau / continued..."
    → bảng bị cắt trang, cần merge với bảng tiếp theo.
    """
    lt = _get_logical_table(table_node)
    if lt is None:
        return False
    anchor_rows = lt.anchor_rows()
    if not anchor_rows:
        return False
    last_anchor = anchor_rows[-1]
    cells = lt.cells_in_row(last_anchor)
    non_empty = [_norm(c.text) for c in cells if _norm(c.text)]
    if not non_empty:
        return False
    return all(_is_skip_pattern(t) for t in non_empty)


def _remove_last_anchor_row(lt: LogicalTable) -> None:
    """
    Xoá tất cả master cells có anchor_row == anchor_row cuối cùng.
    Recalculate total_rows từ cells thực tế sau khi xoá.
    """
    anchor_rows = lt.anchor_rows()
    if not anchor_rows:
        return
    last_anchor = anchor_rows[-1]
    lt.cells = [c for c in lt.cells if c.anchor_row != last_anchor]
    if lt.cells:
        lt.total_rows = max(c.anchor_row + c.row_span for c in lt.cells)
    else:
        lt.total_rows = 0


def _has_repeated_header(base_lt: LogicalTable, extra_lt: LogicalTable) -> bool:
    """
    Kiểm tra extra_lt có lặp lại header của base_lt không.
    Dùng để quyết định có bỏ row 0 của extra khi merge không.
    """
    base_header  = "|".join(_norm(c.text) for c in base_lt.cells_in_row(0))
    extra_header = "|".join(_norm(c.text) for c in extra_lt.cells_in_row(0))
    if not base_header.replace("|", "").strip():
        return False
    if not extra_header.replace("|", "").strip():
        return False
    return base_header == extra_header


def _normalize_col_span(
    cell: LogicalCell,
    extra_lt: LogicalTable,
    base_total_cols: int,
) -> int:
    """
    Fix col_span của cell khi grid của extra ít hơn grid của base.

    Vấn đề: bảng trang trước có subheader làm total_cols lớn hơn
    (vd: 5 grid cols), bảng trang sau không có subheader (3 grid cols).
    Sau merge, cell cuối cùng theo chiều ngang của bảng sau chỉ có
    col_span=1 trong khi cần col_span=3 để lấp đầy đến hết base grid.

    Fix: nếu cell này là cell cuối cùng theo chiều ngang trong extra,
    kéo col_span đến hết total_cols của base.
    """
    body_cells = [c for c in extra_lt.cells if c.anchor_row > 0]
    if not body_cells:
        return cell.col_span
    extra_max_col = max(c.anchor_col for c in body_cells)
    if cell.anchor_col == extra_max_col:
        return base_total_cols - cell.anchor_col
    return cell.col_span


def _merge_logical_tables(
    base_lt: LogicalTable,
    extra_lt: LogicalTable,
) -> None:
    repeated = _has_repeated_header(base_lt, extra_lt)
    skip_count = 1 if repeated else 0
    offset = base_lt.total_rows
    base_total_cols = base_lt.total_cols

    for cell in extra_lt.cells:
        if repeated and cell.anchor_row == 0:
            continue

        col_span = _normalize_col_span(cell, extra_lt, base_total_cols)

        base_lt.cells.append(LogicalCell(
            uid            = cell.uid,
            anchor_row     = cell.anchor_row + offset - skip_count,
            anchor_col     = cell.anchor_col,
            row_span       = cell.row_span,
            col_span       = col_span,
            text           = cell.text,
            text_display   = cell.text_display,
            content_blocks = list(cell.content_blocks),
        ))

    if base_lt.cells:
        base_lt.total_rows = max(
            c.anchor_row + c.row_span for c in base_lt.cells
        )

def _merge_two_tables(base: DocNode, extra: DocNode) -> None:
    """
    Merge extra vào base ở cả LogicalTable lẫn content dict.
    """
    base_lt  = _get_logical_table(base)
    extra_lt = _get_logical_table(extra)

    if base_lt is None or extra_lt is None:
        return

    _merge_logical_tables(base_lt, extra_lt)

    base.content["row_count"] = base_lt.total_rows
    base.content["col_count"] = base_lt.total_cols


# ══════════════════════════════════════════════════════════════════════════════
# Public API
# ══════════════════════════════════════════════════════════════════════════════

def _can_merge(prev: Block, curr: Block) -> bool:
    """
    Hai bảng liên tiếp có thể merge khi:
        1. Cùng type table
        2. Header row giống nhau (hard requirement)
        3. Hàng cuối của prev là "tiếp trang sau..." (continuation signal)

    Bỏ check col_count:
        col_count dễ bị lệch do subheader/gridSpan khác nhau giữa 2 trang
        (ví dụ: bảng trang trước có subheader tách 1 cột thành 3 grid cols,
        trang sau không có subheader → total_cols khác nhau dù cùng 1 bảng).
        header_key match đã đủ chặt để đảm bảo đây là cùng 1 bảng.

    Bỏ điều kiện heading_ctx:
        Bảng layout nhiều trang rất dễ bị lệch heading_ctx vì
        block_builder inject từ heading gần nhất — không đáng tin
        khi bảng chiếm nhiều trang.
    """
    if prev.type != "table" or curr.type != "table":
        return False

    # Header phải khớp
    prev_header = _get_header_key(prev.node)
    curr_header = _get_header_key(curr.node)
    if prev_header is None or curr_header is None:
        return False
    if prev_header != curr_header:
        return False

    # Hàng cuối phải là continuation marker
    if not _last_anchor_row_is_continue(prev.node):
        return False

    return True


def merge_consecutive_tables(blocks: List[Block]) -> List[Block]:
    """
    Duyệt blocks, merge các cặp table liên tiếp bị cắt trang.
    Chain 3+ bảng được xử lý tự nhiên vì mỗi lần merge xong,
    result[-1] là bảng đã gộp và tiếp tục check với bảng tiếp theo.
    """
    if not blocks:
        return blocks

    result: List[Block] = []

    for block in blocks:
        if result and _can_merge(result[-1], block):
            prev = result[-1]

            # Bước 1: xoá "tiếp trang sau" row khỏi base
            prev_lt = _get_logical_table(prev.node)
            if prev_lt is not None:
                _remove_last_anchor_row(prev_lt)

            # Bước 2: merge extra vào base
            _merge_two_tables(prev.node, block.node)

            # Bước 3: recompute signature sau merge
            prev.signature = signature(
                prev.node, heading_ctx=prev.heading_ctx or ""
            )
            continue

        result.append(block)

    return result
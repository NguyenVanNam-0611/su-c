# src/services/diff/table/table_serialize.py
"""
Serialize LogicalTable / LogicalCell → dict để trả về frontend.

Bỏ hoàn toàn:
- build_row_display_cells (frontend tự render từ anchor + span)
- serialize_node / serialize_row dựa trên DocNode row/cell

Thay bằng:
- serialize_logical_cell   — LogicalCell → dict với đủ rowspan/colspan
- serialize_logical_table  — LogicalTable → dict với cells flat list
- get_header_row           — row đầu tiên đã serialize

Frontend nhận cells flat list + anchor/span → tự dựng CSS Grid.
Không cần backend tính display grid nữa.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from src.services.models.logical_table import (
    ImagePayload,
    LogicalCell,
    LogicalTable,
    ParagraphPayload,
)
from src.services.extractor.utils import norm_text as _norm
from src.services.diff.table.table_helpers import get_anchor_rows, get_cells_in_row


# ══════════════════════════════════════════════════════════════════════════════
# Image serializer
# ══════════════════════════════════════════════════════════════════════════════

def serialize_image(img: ImagePayload) -> Dict[str, Any]:
    return {
        "uid":       img.uid,
        "image_url": img.image_url,
        "sha256":    img.sha256,
        "width_px":  img.width_px,
        "height_px": img.height_px,
        "mime":      img.mime,
    }


# ══════════════════════════════════════════════════════════════════════════════
# Paragraph serializer
# ══════════════════════════════════════════════════════════════════════════════

def serialize_paragraph(para: ParagraphPayload) -> Dict[str, Any]:
    return {
        "uid":          para.uid,
        "text":         para.text,
        "text_display": para.text_display,
        "images":       [serialize_image(img) for img in para.images],
    }


# ══════════════════════════════════════════════════════════════════════════════
# Cell serializer
# ══════════════════════════════════════════════════════════════════════════════

def serialize_logical_cell(cell: Optional[LogicalCell]) -> Optional[Dict[str, Any]]:
    """
    Serialize LogicalCell → dict đầy đủ cho frontend.

    Frontend dùng anchor_row, anchor_col, row_span, col_span
    để tự render CSS Grid — không cần backend tính display grid.
    """
    if cell is None:
        return None

    # Collect tất cả image_url để frontend truy cập nhanh
    image_urls: List[str] = []
    for img in cell.images:
        if img.image_url:
            image_urls.append(img.image_url)
    for para in cell.paragraphs:
        for img in para.images:
            if img.image_url:
                image_urls.append(img.image_url)

    return {
        "uid":          cell.uid,
        "anchor_row":   cell.anchor_row,
        "anchor_col":   cell.anchor_col,
        "row_span":     cell.row_span,
        "col_span":     cell.col_span,
        "text":         cell.text,
        "text_display": cell.text_display,
        "paragraphs":   [serialize_paragraph(p) for p in cell.paragraphs],
        "images":       image_urls,
        "image_details": [serialize_image(img) for img in cell.images],
        "nested_table": serialize_logical_table(cell.nested_table) if cell.nested_table else None,
    }


# ══════════════════════════════════════════════════════════════════════════════
# Table serializer
# ══════════════════════════════════════════════════════════════════════════════

def serialize_logical_table(tbl: Optional[LogicalTable]) -> Optional[Dict[str, Any]]:
    """
    Serialize LogicalTable → dict.

    cells: flat list tất cả master cells với anchor + span.
    Frontend tự dựng grid từ đây — không cần rows wrapper.
    """
    if tbl is None:
        return None

    return {
        "uid":        tbl.uid,
        "total_rows": tbl.total_rows,
        "total_cols": tbl.total_cols,
        "cells":      [serialize_logical_cell(c) for c in tbl.cells],
    }


# ══════════════════════════════════════════════════════════════════════════════
# Header row
# ══════════════════════════════════════════════════════════════════════════════

def get_header_row(tbl: LogicalTable) -> Optional[Dict[str, Any]]:
    """
    Trả về cells của anchor row đầu tiên — dùng làm header.
    """
    rows = get_anchor_rows(tbl)
    if not rows:
        return None
    first_row = rows[0]
    return {
        "anchor_row": first_row,
        "cells": [serialize_logical_cell(c) for c in get_cells_in_row(tbl, first_row)],
    }
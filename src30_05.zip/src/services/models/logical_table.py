"""
models/logical_table.py
~~~~~~~~~~~~~~~~~~~~~~~
Data model cho table theo logical/master-cell approach.

Mục tiêu:
    - Chỉ lưu master cells, không lưu continuation cell của merge.
    - Giữ đúng thứ tự nội dung trong cell bằng content_blocks.
    - Nested table luôn nằm bên trong cell, không bị bung thành row của table cha.
    - Dùng được cho diff theo logical rows và render frontend.

Dùng bởi:
    - extractor/table.py
    - diff/table/table_diff.py
    - diff/table/table_serialize.py
    - serializer/json_builder.py
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


# ═════════════════════════════════════════════════════════════════════
# Payload models
# ═════════════════════════════════════════════════════════════════════

@dataclass
class ImagePayload:
    uid: str
    image_url: Optional[str] = None
    sha256: Optional[str] = None
    width_px: Optional[int] = None
    height_px: Optional[int] = None
    mime: Optional[str] = None

    def signature(self) -> str:
        if self.sha256:
            return f"IMG:{self.sha256[:16]}"
        if self.image_url:
            return f"IMG_URL:{self.image_url}"
        return f"IMG:{self.uid}"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "uid": self.uid,
            "image_url": self.image_url,
            "sha256": self.sha256,
            "width_px": self.width_px,
            "height_px": self.height_px,
            "mime": self.mime,
        }


@dataclass
class ParagraphPayload:
    uid: str
    text: str = ""           # normalized để diff/signature
    text_display: str = ""   # raw để render
    images: List[ImagePayload] = field(default_factory=list)

    def signature(self) -> str:
        parts = []
        if self.text:
            parts.append(f"TXT:{self.text[:120]}")
        for img in self.images:
            parts.append(img.signature())
        return "|".join(parts) or f"P_EMPTY:{self.uid}"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "uid": self.uid,
            "text": self.text,
            "text_display": self.text_display,
            "images": [img.to_dict() for img in self.images],
        }


@dataclass
class ShapePayload:
    uid: str
    text: str = ""
    text_display: str = ""
    images: List[ImagePayload] = field(default_factory=list)

    def signature(self) -> str:
        parts = [f"SHP:{self.text[:80]}"] if self.text else [f"SHP:{self.uid}"]
        for img in self.images:
            parts.append(img.signature())
        return "|".join(parts)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "uid": self.uid,
            "text": self.text,
            "text_display": self.text_display,
            "images": [img.to_dict() for img in self.images],
        }


@dataclass
class CellContentBlock:
    """
    Một block nội dung trong cell, giữ đúng thứ tự xuất hiện trong Word.

    type:
        - "paragraph"
        - "image"
        - "table"
        - "shape"
    """
    type: str
    payload: Any

    def signature(self) -> str:
        if self.type == "paragraph" and hasattr(self.payload, "signature"):
            return self.payload.signature()

        if self.type == "image" and hasattr(self.payload, "signature"):
            return self.payload.signature()

        if self.type == "shape" and hasattr(self.payload, "signature"):
            return self.payload.signature()

        if self.type == "table" and hasattr(self.payload, "compact_signature"):
            return f"TBL:{self.payload.compact_signature()}"

        return f"{self.type.upper()}:UNKNOWN"

    def to_dict(self) -> Dict[str, Any]:
        payload = self.payload

        if hasattr(payload, "to_dict"):
            payload_dict = payload.to_dict()
        elif isinstance(payload, dict):
            payload_dict = payload
        else:
            payload_dict = {"value": payload}

        return {
            "type": self.type,
            "payload": payload_dict,
        }


# ═════════════════════════════════════════════════════════════════════
# Logical cell / row / table
# ═════════════════════════════════════════════════════════════════════

@dataclass
class LogicalCell:
    uid: str
    anchor_row: int
    anchor_col: int
    row_span: int = 1
    col_span: int = 1

    # Text tổng hợp để diff nhanh
    text: str = ""
    text_display: str = ""

    # Nội dung đầy đủ theo đúng thứ tự trong cell
    content_blocks: List[CellContentBlock] = field(default_factory=list)

    # Backward-compatible fields: giữ để code cũ chưa vỡ ngay
    paragraphs: List[ParagraphPayload] = field(default_factory=list)
    images: List[ImagePayload] = field(default_factory=list)
    nested_table: Optional["LogicalTable"] = None

    def is_empty(self) -> bool:
        return (
            not self.text
            and not self.text_display
            and not self.content_blocks
            and not self.paragraphs
            and not self.images
            and self.nested_table is None
        )

    def spans_row(self, row: int) -> bool:
        return self.anchor_row <= row < self.anchor_row + self.row_span

    def spans_col(self, col: int) -> bool:
        return self.anchor_col <= col < self.anchor_col + self.col_span

    def covers(self, row: int, col: int) -> bool:
        return self.spans_row(row) and self.spans_col(col)

    def is_anchor_at(self, row: int, col: int) -> bool:
        return self.anchor_row == row and self.anchor_col == col

    def anchor_key(self) -> str:
        return f"r{self.anchor_row}c{self.anchor_col}"

    def content_key(self, max_chars: int = 120) -> str:
        """
        Key nhận dạng cell cho similarity matching.

        Không chỉ dùng text, vì cell có thể chỉ có:
            - image
            - nested table
            - shape
            - empty merged cell
        """
        parts: List[str] = []

        if self.text:
            parts.append(f"TXT:{self.text[:max_chars]}")

        for block in self.content_blocks:
            parts.append(block.signature())

        # fallback cho code cũ nếu extractor chưa fill content_blocks
        if not self.content_blocks:
            for p in self.paragraphs:
                parts.append(p.signature())
            for img in self.images:
                parts.append(img.signature())
            if self.nested_table is not None:
                parts.append(f"TBL:{self.nested_table.compact_signature()}")

        if parts:
            return "|".join(parts)

        return f"EMPTY:{self.anchor_row}:{self.anchor_col}:{self.row_span}x{self.col_span}"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "uid": self.uid,
            "anchor_row": self.anchor_row,
            "anchor_col": self.anchor_col,
            "row_span": self.row_span,
            "col_span": self.col_span,
            "text": self.text,
            "text_display": self.text_display,

            # chuẩn mới cho frontend
            "content_blocks": [b.to_dict() for b in self.content_blocks],

            # giữ lại để frontend/code cũ chưa chết ngay
            "paragraphs": [p.to_dict() for p in self.paragraphs],
            "images": [img.to_dict() for img in self.images],
            "nested_table": self.nested_table.to_dict() if self.nested_table else None,
        }


@dataclass
class LogicalRow:
    """
    Một logical row theo index hàng của table cha.

    cells gồm:
        - anchor cells bắt đầu ở row này
        - spanning cells từ row trên kéo xuống

    Khi tạo signature để match row, chỉ dùng anchor cells để tránh lặp nội dung rowspan.
    """
    physical_row: int
    cells: List[LogicalCell] = field(default_factory=list)

    def anchor_cells(self) -> List[LogicalCell]:
        return [
            c for c in self.cells
            if c.anchor_row == self.physical_row
        ]

    def spanning_cells(self) -> List[LogicalCell]:
        return [
            c for c in self.cells
            if c.anchor_row < self.physical_row
        ]

    def is_anchor_row(self) -> bool:
        return bool(self.anchor_cells())

    def signature(self, max_chars: int = 120) -> str:
        anchors = sorted(self.anchor_cells(), key=lambda c: c.anchor_col)

        parts = []
        for cell in anchors:
            parts.append(cell.content_key(max_chars=max_chars))

        if parts:
            return "|".join(parts)

        # Row chỉ toàn spanning cell
        span_parts = [
            f"SPAN:{c.anchor_key()}:{c.row_span}x{c.col_span}"
            for c in self.spanning_cells()
        ]

        return "|".join(span_parts) or f"ROW_EMPTY:{self.physical_row}"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "physical_row": self.physical_row,
            "cells": [c.to_dict() for c in self.cells],
            "anchor_cells": [c.uid for c in self.anchor_cells()],
            "spanning_cells": [c.uid for c in self.spanning_cells()],
            "signature": self.signature(),
        }


@dataclass
class LogicalTable:
    uid: str
    total_rows: int
    total_cols: int
    cells: List[LogicalCell] = field(default_factory=list)

    # ─────────────────────────────────────────────────────────────
    # Lookup helpers
    # ─────────────────────────────────────────────────────────────

    def get(self, row: int, col: int) -> Optional[LogicalCell]:
        """
        Lấy cell visible tại vị trí row/col.
        Nếu vị trí nằm trong merged area, trả về master cell.
        """
        for cell in self.cells:
            if cell.covers(row, col):
                return cell
        return None

    def get_master(self, row: int, col: int) -> Optional[LogicalCell]:
        """
        Chỉ trả về cell nếu row/col đúng anchor.
        """
        for cell in self.cells:
            if cell.is_anchor_at(row, col):
                return cell
        return None

    def cells_in_row(self, row: int) -> List[LogicalCell]:
        """
        Chỉ master cells có anchor_row == row.
        """
        return sorted(
            [c for c in self.cells if c.anchor_row == row],
            key=lambda c: c.anchor_col,
        )

    def logical_row_cells(self, row: int) -> List[LogicalCell]:
        """
        Cells visible tại row này, gồm cả spanning cells.
        """
        return sorted(
            [c for c in self.cells if c.spans_row(row)],
            key=lambda c: c.anchor_col,
        )

    def anchor_rows(self) -> List[int]:
        return sorted({c.anchor_row for c in self.cells})

    # ─────────────────────────────────────────────────────────────
    # Logical rows
    # ─────────────────────────────────────────────────────────────

    def logical_rows(self) -> List[LogicalRow]:
        result: List[LogicalRow] = []

        for row_idx in range(self.total_rows):
            cells = self.logical_row_cells(row_idx)
            if cells:
                result.append(
                    LogicalRow(
                        physical_row=row_idx,
                        cells=cells,
                    )
                )

        return result

    def row_signature(self, row: int, max_chars: int = 120) -> str:
        return LogicalRow(
            physical_row=row,
            cells=self.logical_row_cells(row),
        ).signature(max_chars=max_chars)

    def signature_list(self, max_chars: int = 120) -> List[str]:
        return [
            row.signature(max_chars=max_chars)
            for row in self.logical_rows()
        ]

    def compact_signature(self, max_rows: int = 12, max_chars: int = 80) -> str:
        """
        Signature ngắn cho nested table / table similarity.
        Không dùng để render.
        """
        row_sigs = self.signature_list(max_chars=max_chars)
        body = "#".join(row_sigs[:max_rows])
        return f"{self.total_rows}x{self.total_cols}:{body}"

    # ─────────────────────────────────────────────────────────────
    # Content summary helpers
    # ─────────────────────────────────────────────────────────────

    def text_content(self) -> str:
        return " ".join(c.text for c in self.cells if c.text).strip()

    def has_nested_table(self) -> bool:
        for cell in self.cells:
            if cell.nested_table is not None:
                return True
            for block in cell.content_blocks:
                if block.type == "table":
                    return True
        return False

    def has_images(self) -> bool:
        for cell in self.cells:
            if cell.images:
                return True
            for block in cell.content_blocks:
                if block.type == "image":
                    return True
        return False

    # ─────────────────────────────────────────────────────────────
    # Serialize
    # ─────────────────────────────────────────────────────────────

    def to_dict(self) -> Dict[str, Any]:
        return {
            "uid": self.uid,
            "total_rows": self.total_rows,
            "total_cols": self.total_cols,
            "cells": [cell.to_dict() for cell in self.cells],
            "rows": [row.to_dict() for row in self.logical_rows()],
        }
from .com_pager    import get_pages_via_com
from .page_injector import collect_uid_text_pairs, inject_pages

__all__ = [
    "get_pages_via_com",
    "collect_uid_text_pairs",
    "inject_pages",
]
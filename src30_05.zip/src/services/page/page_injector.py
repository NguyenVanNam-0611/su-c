"""
page/page_injector.py
~~~~~~~~~~~~~~~~~~~~~
Inject page thật (từ COM) vào DocNode tree.

Chiến lược:
- heading/paragraph : dùng content["text"] làm search key
- table             : dùng text cell đầu tiên không rỗng
- image/shape       : skip (không có text để Find)

Nếu COM không trả page cho uid nào đó → giữ nguyên
page cũ (ước lượng từ extract hoặc = 1).
"""
from __future__ import annotations

import logging
from typing import Dict, List, Tuple

from src.services.models.docnode import DocNode

logger = logging.getLogger(__name__)


def collect_uid_text_pairs(
    root: DocNode,
) -> List[Tuple[str, str]]:
    """
    Duyệt tree, trả list (uid, search_text) cho các node
    có thể Find bằng COM.
    """
    pairs: List[Tuple[str, str]] = []

    def _walk(node: DocNode) -> None:
        t = node.type

        if t in ("heading", "paragraph"):
            text = (node.content.get("text") or "").strip()
            if text:
                pairs.append((node.uid, text[:100]))

        elif t == "table":
            # Lấy text cell đầu tiên không rỗng
            key = _first_cell_text(node)
            if key:
                pairs.append((node.uid, key))

        # Duyệt children (nhưng không đi vào trong table)
        if t != "table":
            for child in (node.children or []):
                _walk(child)

    for child in (root.children or []):
        _walk(child)

    return pairs


def inject_pages(
    root: DocNode,
    page_map: Dict[str, int],
) -> None:
    """
    Ghi page_map vào node.content["page"] cho toàn bộ tree.
    In-place.
    """
    if not page_map:
        return

    def _walk(node: DocNode) -> None:
        if node.uid in page_map:
            node.content["page"] = page_map[node.uid]

        for child in (node.children or []):
            _walk(child)

    _walk(root)
    logger.info(f"[INJECTOR] Đã inject page cho {len(page_map)} nodes.")


def _first_cell_text(table_node: DocNode) -> str:
    """
    Tìm text cell đầu tiên không rỗng trong table node.
    Hỗ trợ cả logical_table lẫn row/cell children.
    """
    lt = getattr(table_node, "logical_table", None)

    if lt is not None:
        for cell in lt.cells:
            t = (cell.text or "").strip()
            if t:
                return t[:100]
        return ""

    # fallback: duyệt children
    for row in (table_node.children or []):
        if row.type != "row":
            continue
        for cell in (row.children or []):
            if cell.type != "cell":
                continue
            text = (cell.content.get("text") or "").strip()
            if text:
                return text[:100]

    return ""
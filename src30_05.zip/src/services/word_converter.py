import os
import shutil
import tempfile
import pythoncom
import win32com.client


WD_FORMAT_XML_DOCUMENT = 16


def convert_doc_to_docx_if_needed(file_path: str) -> str:
    """
    .doc  -> convert sang .docx
    .docx -> giữ nguyên
    """
    ext = os.path.splitext(file_path)[1].lower()

    if ext == ".docx":
        return file_path

    if ext != ".doc":
        raise ValueError(f"Unsupported file type: {ext}")

    abs_path = os.path.abspath(file_path)

    temp_dir = tempfile.gettempdir()
    base_name = os.path.splitext(
        os.path.basename(abs_path)
    )[0]

    out_path = os.path.join(
        temp_dir,
        f"{base_name}_converted.docx"
    )

    word = None
    doc = None

    pythoncom.CoInitialize()

    try:
        word = win32com.client.DispatchEx(
            "Word.Application"
        )
        word.Visible = False
        word.DisplayAlerts = 0

        doc = word.Documents.Open(
            abs_path,
            ReadOnly=True,
        )

        doc.SaveAs(
            out_path,
            FileFormat=WD_FORMAT_XML_DOCUMENT
        )

        return out_path

    finally:
        try:
            if doc:
                doc.Close(False)
        except Exception:
            pass

        try:
            if word:
                word.Quit()
        except Exception:
            pass

        pythoncom.CoUninitialize()


def normalize_docx_for_compare(file_path: str) -> str:
    """
    Normalize file trước khi compare.

    - .doc  -> convert sang .docx
    - .docx -> copy temp để tránh lock file
    """
    converted_path = convert_doc_to_docx_if_needed(
        file_path
    )

    temp_dir = tempfile.gettempdir()
    file_name = os.path.basename(converted_path)

    normalized_path = os.path.join(
        temp_dir,
        f"normalized_{file_name}"
    )

    shutil.copy2(
        converted_path,
        normalized_path
    )

    return normalized_path
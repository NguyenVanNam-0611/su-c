// components/DiffSection.jsx
import { MetaRow, WordDiff, EmptyHint, ImgBox } from './WordDiff';
import { TextChangeRow } from './renderers/TextChange';
import { TableChange } from './table/TableChange';

// ─────────────────────────────────────────────────────────────
// IMAGE  (image_*)
// ─────────────────────────────────────────────────────────────
function ImageChangeRow({ change }) {
    const kind = change.change_kind || 'replace';
    const imgChg = change.image_change || {};
    const leftImg = change.left_img || imgChg.left_img || change.left || null;
    const rightImg = change.right_img || imgChg.right_img || change.right || null;
    const leftUrl = leftImg?.image_url || leftImg?.image?.image_url || null;
    const rightUrl = rightImg?.image_url || rightImg?.image?.image_url || null;

    return (
        <div className={`change-row kind-${kind}`}>
            <div className="change-cell left">
                <MetaRow change={change} />
                {leftUrl
                    ? <div className="img-box"><img src={leftUrl} alt="original" /></div>
                    : <div className="img-box"><div className="img-none">{kind === 'insert' ? '(chưa tồn tại)' : '(không có)'}</div></div>
                }
            </div>
            <div className="change-cell right">
                <div className="meta-spacer" />
                {rightUrl
                    ? <div className="img-box"><img src={rightUrl} alt="modified" /></div>
                    : <div className="img-box"><div className="img-none">{kind === 'delete' ? '(đã xóa)' : '(không có)'}</div></div>
                }
            </div>
        </div>
    );
}

// ─────────────────────────────────────────────────────────────
// SHAPE helpers
// ─────────────────────────────────────────────────────────────
function ShapeLines({ lines = [], lineClass = 'line-equal' }) {
    return (
        <div className="shape-lines">
            {lines.map((l, i) => (
                <div key={i} className={`shape-line ${lineClass}`}>{l}</div>
            ))}
        </div>
    );
}

function _imgUrl(payload) {
    return payload?.image_url || payload?.image?.image_url || null;
}

function _nodeImgUrls(node) {
    if (!node) return [];
    return (node.children || [])
        .filter(ch => ch?.type === 'image')
        .map(ch => ch.image_url || ch.image?.image_url || ch.content?.image_url)
        .filter(Boolean);
}

function ShapeImgLine({ url, lineClass }) {
    if (!url) return null;
    return (
        <div className={`shape-line ${lineClass}`} style={{ padding: '4px 0' }}>
            <ImgBox url={url} style={{ maxWidth: '100%' }} />
        </div>
    );
}

// ─────────────────────────────────────────────────────────────
// SHAPE  (shape_*)
// ─────────────────────────────────────────────────────────────
function ShapeChangeRow({ change }) {
    const kind = change.change_kind || 'replace';
    const shapeChanges = change.shape_changes || [];

    if (kind === 'insert') {
        const lines = (change.right?.shape_text_lines || []).filter(l => !l.startsWith('['));
        const imgs = change.right?.shape_images || [];
        return (
            <div className={`change-row kind-${kind}`}>
                <div className="change-cell left">
                    <MetaRow change={change} />
                    <EmptyHint style={{ padding: 8 }}>(chưa tồn tại)</EmptyHint>
                </div>
                <div className="change-cell right">
                    <div className="meta-spacer" />
                    {lines.length > 0 && <ShapeLines lines={lines} lineClass="line-ins" />}
                    {imgs.map((img, i) => <ShapeImgLine key={i} url={img.image_url} lineClass="line-ins" />)}
                    {!lines.length && !imgs.length && <EmptyHint style={{ padding: 8 }}>(shape trống)</EmptyHint>}
                </div>
            </div>
        );
    }

    if (kind === 'delete') {
        const lines = (change.left?.shape_text_lines || []).filter(l => !l.startsWith('['));
        const imgs = change.left?.shape_images || [];
        return (
            <div className={`change-row kind-${kind}`}>
                <div className="change-cell left">
                    <MetaRow change={change} />
                    {lines.length > 0 && <ShapeLines lines={lines} lineClass="line-del" />}
                    {imgs.map((img, i) => <ShapeImgLine key={i} url={img.image_url} lineClass="line-del" />)}
                    {!lines.length && !imgs.length && <EmptyHint style={{ padding: 8 }}>(shape trống)</EmptyHint>}
                </div>
                <div className="change-cell right">
                    <div className="meta-spacer" />
                    <EmptyHint style={{ padding: 8 }}>(đã xóa)</EmptyHint>
                </div>
            </div>
        );
    }

    if (change.shape_cleared) {
        const lines = change.left?.shape_text_lines || change.shape_text_preview || [];
        const imgs = change.left?.shape_images || [];
        return (
            <div className={`change-row kind-${kind}`}>
                <div className="change-cell left">
                    <MetaRow change={change} />
                    {lines.length > 0 && <ShapeLines lines={lines} lineClass="line-del" />}
                    {imgs.map((img, i) => <ShapeImgLine key={i} url={img.image_url} lineClass="line-del" />)}
                    {!lines.length && !imgs.length && <EmptyHint>(trống)</EmptyHint>}
                    <div className="shape-cleared-note">★ Toàn bộ nội dung đã bị xóa</div>
                </div>
                <div className="change-cell right">
                    <div className="meta-spacer" />
                    <EmptyHint style={{ padding: 8 }}>(shape đã được xóa nội dung)</EmptyHint>
                </div>
            </div>
        );
    }

    if (!shapeChanges.length) {
        const lines = change.left?.shape_text_lines || [];
        const body = lines.length
            ? <ShapeLines lines={lines} lineClass="line-equal" />
            : <EmptyHint style={{ padding: 8 }}>(trống)</EmptyHint>;
        return (
            <div className={`change-row kind-${kind}`}>
                <div className="change-cell left"><MetaRow change={change} />{body}</div>
                <div className="change-cell right"><div className="meta-spacer" />{body}</div>
            </div>
        );
    }

    const leftItems = [];
    const rightItems = [];

    shapeChanges.forEach((sc, idx) => {
        const scType = sc.type || '';
        const orig = sc.original;
        const mod = sc.modified;
        const origText = orig?.content?.text || orig?.text || '';
        const modText = mod?.content?.text || mod?.text || '';

        if (scType === 'paragraph_equal') {
            leftItems.push(
                <div key={`L${idx}`} className="shape-line line-equal">
                    {origText}
                    {_nodeImgUrls(orig).map((u, i) => <ImgBox key={i} url={u} style={{ marginTop: 4 }} />)}
                </div>
            );
            rightItems.push(
                <div key={`R${idx}`} className="shape-line line-equal">
                    {modText || origText}
                    {_nodeImgUrls(mod).map((u, i) => <ImgBox key={i} url={u} style={{ marginTop: 4 }} />)}
                </div>
            );
        } else if (scType === 'paragraph_deleted') {
            leftItems.push(
                <div key={`L${idx}`} className="shape-line line-del">
                    {origText}
                    {_nodeImgUrls(orig).map((u, i) => <ImgBox key={i} url={u} style={{ marginTop: 4 }} />)}
                </div>
            );
        } else if (scType === 'paragraph_inserted') {
            rightItems.push(
                <div key={`R${idx}`} className="shape-line line-ins">
                    {modText}
                    {_nodeImgUrls(mod).map((u, i) => <ImgBox key={i} url={u} style={{ marginTop: 4 }} />)}
                </div>
            );
        } else if (scType === 'paragraph_modified') {
            const wd = sc.word_diff || {};
            leftItems.push(
                <div key={`L${idx}`} className="shape-line line-modified">
                    <WordDiff wd={wd} side="left" />
                    {_nodeImgUrls(orig).map((u, i) => <ImgBox key={i} url={u} style={{ marginTop: 4 }} />)}
                </div>
            );
            rightItems.push(
                <div key={`R${idx}`} className="shape-line line-modified">
                    <WordDiff wd={wd} side="right" />
                    {_nodeImgUrls(mod).map((u, i) => <ImgBox key={i} url={u} style={{ marginTop: 4 }} />)}
                </div>
            );
        } else if (scType === 'image_equal') {
            const url = _imgUrl(sc.left) || _imgUrl(sc.right);
            if (url) {
                leftItems.push(<ShapeImgLine key={`L${idx}`} url={url} lineClass="line-equal" />);
                rightItems.push(<ShapeImgLine key={`R${idx}`} url={url} lineClass="line-equal" />);
            }
        } else if (scType === 'image_modified') {
            const lUrl = _imgUrl(sc.left);
            const rUrl = _imgUrl(sc.right);
            if (lUrl) leftItems.push(<ShapeImgLine key={`L${idx}`} url={lUrl} lineClass="line-del" />);
            if (rUrl) rightItems.push(<ShapeImgLine key={`R${idx}`} url={rUrl} lineClass="line-ins" />);
        } else if (scType === 'image_added') {
            const url = _imgUrl(sc.right);
            if (url) rightItems.push(<ShapeImgLine key={`R${idx}`} url={url} lineClass="line-ins" />);
        } else if (scType === 'image_deleted') {
            const url = _imgUrl(sc.left);
            if (url) leftItems.push(<ShapeImgLine key={`L${idx}`} url={url} lineClass="line-del" />);
        }
    });

    return (
        <div className={`change-row kind-${kind}`}>
            <div className="change-cell left">
                <MetaRow change={change} />
                {leftItems.length
                    ? <div className="shape-lines">{leftItems}</div>
                    : <EmptyHint style={{ padding: 8 }}>—</EmptyHint>
                }
            </div>
            <div className="change-cell right">
                <div className="meta-spacer" />
                {rightItems.length
                    ? <div className="shape-lines">{rightItems}</div>
                    : <EmptyHint style={{ padding: 8 }}>—</EmptyHint>
                }
            </div>
        </div>
    );
}

// ─────────────────────────────────────────────────────────────
// SECTION
// ─────────────────────────────────────────────────────────────
export function DiffSection({ section, onDeleteChange, onDeleteSubRow }) {
    const heading = (section.heading || '(No heading)').split('>').pop().trim();
    const changes = section.changes || [];

    return (
        <div className="section-block">
            <div className="section-head">
                <div className="section-head-cell">{heading}</div>
                <div className="section-head-cell">{heading}</div>
            </div>
            <div className="col-labels">
                <div className="col-label">Original</div>
                <div className="col-label">Modified</div>
            </div>
            {changes.map(change => {
                const t = change.type || '';
                const deleteBtn = onDeleteChange
                    ? <DeleteRowBtn onClick={() => onDeleteChange(section, change)} />
                    : null;

                if (t.startsWith('image_'))
                    return (
                        <ChangeRowWrapper key={change.id} deleteBtn={deleteBtn}>
                            <ImageChangeRow change={change} />
                        </ChangeRowWrapper>
                    );

                if (t.startsWith('table_'))
                    return (
                        <ChangeRowWrapper key={change.id} deleteBtn={deleteBtn}>
                            <TableChange
                                change={change}
                                onDeleteSubRow={onDeleteSubRow
                                    ? (subIdx) => onDeleteSubRow(section, change, subIdx)
                                    : null
                                }
                            />
                        </ChangeRowWrapper>
                    );

                if (t.startsWith('shape_'))
                    return (
                        <ChangeRowWrapper key={change.id} deleteBtn={deleteBtn}>
                            <ShapeChangeRow change={change} />
                        </ChangeRowWrapper>
                    );

                if (t.startsWith('paragraph_') || t.startsWith('heading_'))
                    return (
                        <ChangeRowWrapper key={change.id} deleteBtn={deleteBtn}>
                            <TextChangeRow change={change} />
                        </ChangeRowWrapper>
                    );

                const lTxt = change.left?.preview_text || change.left?.node?.content?.text || '';
                const rTxt = change.right?.preview_text || change.right?.node?.content?.text || '';
                return (
                    <ChangeRowWrapper key={change.id} deleteBtn={deleteBtn}>
                        <div className={`change-row kind-${change.change_kind || 'replace'}`}>
                            <div className="change-cell left"><MetaRow change={change} /><div className="txt">{lTxt}</div></div>
                            <div className="change-cell right"><div className="meta-spacer" /><div className="txt">{rTxt}</div></div>
                        </div>
                    </ChangeRowWrapper>
                );
            })}
        </div>
    );
}

// ─────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────
function ChangeRowWrapper({ children, deleteBtn }) {
    return (
        <div className="change-row-wrapper">
            {children}
            {deleteBtn}
        </div>
    );
}

function DeleteRowBtn({ onClick }) {
    return (
        <button className="row-delete-btn" onClick={onClick} title="Xóa dòng này" aria-label="Xóa">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="3 6 5 6 21 6" />
                <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" />
                <path d="M10 11v6M14 11v6" />
                <path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" />
            </svg>
        </button>
    );
}
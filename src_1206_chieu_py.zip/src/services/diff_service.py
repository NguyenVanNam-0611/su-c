from __future__ import annotations

from typing import Dict, Any, List

from src.services.extractor.document import extract_doc_tree
from src.services.block.block_builder import build_blocks
from src.services.align.sequence_align import align_blocks
from src.services.serializer.json_builder import build_ui_json

# ── THÊM: COM page pass ────────────────────────────────────────────────────
from src.services.page import (
    get_pages_via_com_index,
    collect_uid_index_pairs,
    inject_pages,
)
# ──────────────────────────────────────────────────────────────────────────────

_DISPLAY_TYPE_MAP = {
    "paragraph_modified": "paragraph",
    "paragraph_inserted": "paragraph",
    "paragraph_deleted":  "paragraph",
    "heading_modified":   "heading",
    "heading_inserted":   "heading",
    "heading_deleted":    "heading",
    "table_modified":     "table",
    "table_inserted":     "table",
    "table_deleted":      "table",
    "image_modified":     "image",
    "image_inserted":     "image",
    "image_deleted":      "image",
    "image_added":        "image",
    "shape_modified":     "shape",
    "shape_inserted":     "shape",
    "shape_deleted":      "shape",
}


class DiffService:
    """
    DiffService
    ===========
    Quy ước cực kỳ quan trọng:
    - Thứ tự hiển thị MUST theo seq_index do json_builder sinh ra
    - TUYỆT ĐỐI không sort lại theo order / id trong service layer
    """

    # ── Normalize helpers ──────────────────────────────────────────────────

    def _normalize_change(self, ch: Dict[str, Any], section_heading: str) -> Dict[str, Any]:
        ch_type = ch.get("type", "")
        display_type = (
            _DISPLAY_TYPE_MAP.get(ch_type)
            or ch.get("display_type")
            or ch_type
                .replace("_modified", "")
                .replace("_inserted", "")
                .replace("_deleted", "")
        )

        order = ch.get("order")
        if order is None:
            left  = ch.get("left")  or {}
            right = ch.get("right") or {}
            candidates = []
            if isinstance(left, dict):
                candidates.append(left.get("order"))
            if isinstance(right, dict):
                candidates.append(right.get("order"))
            order = min((o for o in candidates if o is not None), default=0)

        return {
            **ch,
            "heading": ch.get("heading") if ch.get("heading") is not None else section_heading,
            "left_heading": ch.get("left_heading"),
            "right_heading": ch.get("right_heading"),
            "heading_changed": ch.get("heading_changed", False),
            "order":        order,
            "display_type": display_type,
        }

    def _normalize_section(self, section: Dict[str, Any]) -> Dict[str, Any]:
        heading = section.get("heading") or "(No heading)"
        changes = section.get("changes", []) or []

        normalized_changes = [
            self._normalize_change(ch, heading)
            for ch in changes
        ]

        return {
            "heading": section.get("heading"),
            "left_heading": section.get("left_heading"),
            "right_heading": section.get("right_heading"),
            "heading_changed": section.get("heading_changed", False),
            "changes": normalized_changes,
        }
    # ── COM page injection ─────────────────────────────────────────────────

    @staticmethod
    def _inject_com_pages(docx_path: str, root) -> None:
        """
        Gọi Word COM để lấy page thật bằng index trực tiếp, inject vào DocNode tree.
        Chính xác hơn Find-by-text vì không bị nhầm khi có duplicate text.
        Nếu COM không khả dụng (Linux / pywin32 chưa cài) → bỏ qua,
        giữ nguyên page ước lượng từ extract.
        """
        pairs = collect_uid_index_pairs(root)
        if not pairs:
            return
        page_map = get_pages_via_com_index(docx_path, pairs)
        inject_pages(root, page_map)

    # ── Public API ──────────────────────────────────────────────────────────

    def compare(self, original_path: str, modified_path: str) -> Dict[str, Any]:
        # 1. Extract DocNode trees
        original_root = extract_doc_tree(original_path)
        modified_root = extract_doc_tree(modified_path)

        # 2. COM page injection (chạy sau extract, trước build_blocks)
        #    Fallback tự động nếu không phải Windows hoặc pywin32 thiếu.
        self._inject_com_pages(original_path, original_root)
        self._inject_com_pages(modified_path, modified_root)

        # 3. Build blocks
        original_blocks = build_blocks(original_root)
        modified_blocks = build_blocks(modified_root)

        # 4. Align → opcodes
        opcodes = align_blocks(original_blocks, modified_blocks)

        # 5. Build UI JSON
        result = build_ui_json(original_blocks, modified_blocks, opcodes)

        sections = result.get("sections", []) or []

        # 6. Normalize sections
        normalized_sections = [
            self._normalize_section(section)
            for section in sections
        ]

        total_changes = sum(
            len(section["changes"]) for section in normalized_sections
        )

        return {
            "original_file":  original_path,
            "modified_file":  modified_path,
            "total_sections": len(normalized_sections),
            "total_changes":  total_changes,
            "sections":       normalized_sections,
        }
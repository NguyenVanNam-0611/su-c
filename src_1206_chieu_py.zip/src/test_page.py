# test_com_page.py
import sys
sys.path.insert(0, r"D:\tct_python")

from src.services.page.com_pager import get_pages_via_com
from src.services.page.page_injector import collect_uid_text_pairs
from src.services.extractor.document import extract_doc_tree

path = r"D:\Test_trang.docx"  # ← file có 3+ trang

root = extract_doc_tree(path)
pairs = collect_uid_text_pairs(root)

print(f"Collect được {len(pairs)} pairs")
for uid, text in pairs:
    print(f"  {uid}: {text[:60]!r}")

page_map = get_pages_via_com(path, pairs)
print(f"\npage_map: {page_map}")

# So sánh trước/sau inject
print("\nPage TRƯỚC inject:")
for node in root.walk():
    if node.type in ("heading", "paragraph", "table"):
        print(f"  {node.uid} page={node.content.get('page')} | {node.content.get('text','')[:40]}")

from src.services.page.page_injector import inject_pages
inject_pages(root, page_map)

print("\nPage SAU inject:")
for node in root.walk():
    if node.type in ("heading", "paragraph", "table"):
        print(f"  {node.uid} page={node.content.get('page')} | {node.content.get('text','')[:40]}")
import { WordDiff, MetaRow, EmptyHint, NumberingBadge } from '../WordDiff';

function NumberingPrefix({ numbering }) {
    if (!numbering?.label) return null;
    return <span className="numbering-prefix">{numbering.label}</span>;
}

function TextBody({ wd, side, plainText, numbering }) {
    const hasSpans = Array.isArray(wd?.spans) && wd.spans.length > 0;

    return (
        <div className="txt">
            <NumberingPrefix numbering={numbering} />
            {hasSpans
                ? <WordDiff wd={wd} side={side} />
                : plainText || <EmptyHint>(trống)</EmptyHint>
            }
        </div>
    );
}

export function TextChangeRow({ change }) {
    const kind = change.change_kind || 'replace';
    const wd = change.word_diff || {};
    const fc = change.format_changes || wd.format_changes || {};

    const leftNumbering = change.left?.node?.content?.numbering;
    const rightNumbering = change.right?.node?.content?.numbering;

    const leftPlainTxt =
        change.left?.node?.content?.text_display
        || change.left?.node?.content?.text
        || change.left?.preview_text
        || '';

    const rightPlainTxt =
        change.right?.node?.content?.text_display
        || change.right?.node?.content?.text
        || change.right?.preview_text
        || '';

    if (kind === 'delete') {
        return (
            <div className={`change-row kind-${kind}`}>
                <div className="change-cell left">
                    <MetaRow change={change} />
                    <NumberingBadge formatChanges={fc} />
                    <TextBody
                        wd={wd}
                        side="left"
                        plainText={leftPlainTxt}
                        numbering={leftNumbering}
                    />
                </div>
                <div className="change-cell right">
                    <MetaRow change={change} />
                    <EmptyHint style={{ padding: 8 }}>(đã xóa)</EmptyHint>
                </div>
            </div>
        );
    }

    if (kind === 'insert') {
        return (
            <div className={`change-row kind-${kind}`}>
                <div className="change-cell left">
                    <MetaRow change={change} />
                    <EmptyHint style={{ padding: 8 }}>(chưa tồn tại)</EmptyHint>
                </div>
                <div className="change-cell right">
                    <MetaRow change={change} />
                    <NumberingBadge formatChanges={fc} />
                    <TextBody
                        wd={wd}
                        side="right"
                        plainText={rightPlainTxt}
                        numbering={rightNumbering}
                    />
                </div>
            </div>
        );
    }

    return (
        <div className={`change-row kind-${kind}`}>
            <div className="change-cell left">
                <MetaRow change={change} />
                <NumberingBadge formatChanges={fc} />
                <TextBody
                    wd={wd}
                    side="left"
                    plainText={leftPlainTxt}
                    numbering={leftNumbering}
                />
            </div>
            <div className="change-cell right">
                <MetaRow change={change} />
                <NumberingBadge formatChanges={fc} />
                <TextBody
                    wd={wd}
                    side="right"
                    plainText={rightPlainTxt}
                    numbering={rightNumbering}
                />
            </div>
        </div>
    );
}
// ─────────────────────────────────────────────────────────────
// CellContent.jsx
// ─────────────────────────────────────────────────────────────
import { WordDiff, ImgBox } from './WordDiff';
import { getCellText } from '../utils/diffHelpers';
import { NestedTable } from './NestedTable';
import { NestedTableWithDiff } from './NestedTable';

// ── Utils ────────────────────────────────────────────────────
function getImageKey(img) {
    if (!img) return '';
    return img.sha256 || img.uid || img.image_url || '';
}

function sameImage(a, b) {
    if (!a || !b) return false;
    const ak = getImageKey(a);
    const bk = getImageKey(b);
    return !!ak && !!bk && ak === bk;
}

// ── CellNode — render LogicalCell không diff ──────────────────
export function CellNode({ cell, cellNode, fallbackText = '' }) {
    const node = cell ?? cellNode;
    if (!node) return <>{fallbackText}</>;

    const { content_blocks, nested_table } = node;

    if (nested_table) {
        return (
            <div>
                {(content_blocks || []).map((block, i) => {
                    if (block.type === 'paragraph') {
                        const p = block.payload;
                        const txt = p?.text_display || p?.text || '';
                        return txt ? <div key={i}>{txt}</div> : null;
                    }

                    if (block.type === 'image') {
                        const img = block.payload;
                        return img?.image_url
                            ? <ImgBox key={i} url={img.image_url} style={{ marginTop: 4 }} />
                            : null;
                    }

                    return null;
                })}

                <NestedTable table={nested_table} />
            </div>
        );
    }

    if (content_blocks?.length) {
        return (
            <>
                {content_blocks.map((block, i) => {
                    if (block.type === 'paragraph') {
                        const p = block.payload;
                        if (!p) return null;

                        const txt = p.text_display || p.text || '';
                        const imgs = p.images || [];

                        return (
                            <div key={i}>
                                {txt && <span>{txt}</span>}
                                {imgs.map((img, j) =>
                                    img.image_url
                                        ? <ImgBox key={j} url={img.image_url} style={{ marginTop: 4 }} />
                                        : null
                                )}
                            </div>
                        );
                    }

                    if (block.type === 'image') {
                        const img = block.payload;
                        return img?.image_url
                            ? <ImgBox key={i} url={img.image_url} style={{ marginTop: 4 }} />
                            : null;
                    }

                    if (block.type === 'table') {
                        return <NestedTable key={i} table={block.payload} />;
                    }

                    return null;
                })}
            </>
        );
    }

    const { paragraphs = [], images = [] } = node;

    if (paragraphs.length) {
        return (
            <>
                {paragraphs.map((p, idx) => {
                    const txt = p.text_display || p.text || '';
                    const imgs = p.images || [];

                    return (
                        <div key={p.uid || idx}>
                            {txt && <span>{txt}</span>}
                            {imgs.map((img, i) =>
                                img.image_url
                                    ? <ImgBox key={i} url={img.image_url} style={{ marginTop: 4 }} />
                                    : null
                            )}
                        </div>
                    );
                })}

                {images.map((url, i) =>
                    url ? <ImgBox key={`ci-${i}`} url={url} style={{ marginTop: 4 }} /> : null
                )}
            </>
        );
    }

    const txt = node.text_display || node.text || fallbackText;

    return (
        <>
            {txt && <span>{txt}</span>}
            {images.map((url, i) =>
                url ? <ImgBox key={i} url={url} style={{ marginTop: 4 }} /> : null
            )}
        </>
    );
}

// ── Build lookup maps từ changes array ────────────────────────
function buildChangeMaps(changes) {
    const deletedParaUids = new Set();
    const insertedParaUids = new Set();

    const deletedImgKeys = new Set();
    const insertedImgKeys = new Set();

    const insertedParas = [];
    const insertedImgs = [];

    const modifiedParaMap = new Map();

    for (const ch of changes || []) {
        const t = ch.type || '';

        if (t === 'paragraph_deleted' && ch.original) {
            if (ch.original.uid) deletedParaUids.add(ch.original.uid);
        }

        if (t === 'paragraph_inserted' && ch.modified) {
            insertedParas.push(ch.modified);
            if (ch.modified.uid) insertedParaUids.add(ch.modified.uid);
        }

        if (t === 'paragraph_modified') {
            if (ch.original?.uid) modifiedParaMap.set(ch.original.uid, ch);
            if (ch.modified?.uid) modifiedParaMap.set(ch.modified.uid, ch);
        }

        if (t === 'image_deleted' && ch.original) {
            const key = getImageKey(ch.original);
            if (key) deletedImgKeys.add(key);
        }

        if (t === 'image_added' && ch.modified) {
            insertedImgs.push(ch.modified);
            const key = getImageKey(ch.modified);
            if (key) insertedImgKeys.add(key);
        }

        if (t === 'image_modified') {
            const oldKey = getImageKey(ch.original);
            const newKey = getImageKey(ch.modified);

            if (oldKey) deletedImgKeys.add(oldKey);
            if (newKey) insertedImgKeys.add(newKey);
        }
    }

    return {
        deletedParaUids,
        insertedParaUids,
        deletedImgKeys,
        insertedImgKeys,
        insertedParas,
        insertedImgs,
        modifiedParaMap
    };
}

// ── Render images trong paragraph ─────────────────────────────
function renderParagraphImages(imgs, side, maps) {
    return (imgs || []).map((img, i) => {
        if (!img?.image_url) return null;

        const key = getImageKey(img);
        const isDeleted = maps.deletedImgKeys.has(key);
        const isInserted = maps.insertedImgKeys.has(key);

        if (isDeleted) {
            if (side !== 'left') return null;

            return (
                <div key={i} className="del-span">
                    <ImgBox url={img.image_url} style={{ marginTop: 4 }} />
                </div>
            );
        }

        if (isInserted) {
            if (side !== 'right') return null;

            return (
                <div key={i} className="ins-span">
                    <ImgBox url={img.image_url} style={{ marginTop: 4 }} />
                </div>
            );
        }

        return <ImgBox key={i} url={img.image_url} style={{ marginTop: 4 }} />;
    });
}

// ── Render 1 block từ content_blocks với highlight ────────────
function renderBlock({ block, index, side, maps }) {
    if (!block) return null;

    // ── paragraph block ───────────────────────────────────────
    if (block.type === 'paragraph') {
        const p = block.payload;
        if (!p) return null;

        const uid = p.uid;
        const txt = p.text_display || p.text || '';
        const imgs = p.images || [];

        // paragraph_modified
        if (uid && maps.modifiedParaMap.has(uid)) {
            const ch = maps.modifiedParaMap.get(uid);

            return (
                <div key={index}>
                    <WordDiff wd={ch} side={side} />
                    {renderParagraphImages(imgs, side, maps)}
                </div>
            );
        }

        // paragraph_deleted — chỉ show ở left
        if (uid && maps.deletedParaUids.has(uid)) {
            if (side !== 'left') return null;

            return (
                <div key={index}>
                    {txt && <span className="del-span">{txt}</span>}
                    {renderParagraphImages(imgs, side, maps)}
                </div>
            );
        }

        // paragraph_inserted — chỉ show ở right
        if (uid && maps.insertedParaUids.has(uid)) {
            if (side !== 'right') return null;

            return (
                <div key={index}>
                    {txt && <span className="ins-span">{txt}</span>}
                    {renderParagraphImages(imgs, side, maps)}
                </div>
            );
        }

        // paragraph bình thường
        return (
            <div key={index}>
                {txt && <span>{txt}</span>}
                {renderParagraphImages(imgs, side, maps)}
            </div>
        );
    }

    // ── image block ───────────────────────────────────────────
    if (block.type === 'image') {
        const img = block.payload;
        if (!img?.image_url) return null;

        const key = getImageKey(img);
        const isDeleted = maps.deletedImgKeys.has(key);
        const isInserted = maps.insertedImgKeys.has(key);

        if (isDeleted) {
            if (side !== 'left') return null;

            return (
                <div key={index} className="del-span">
                    <ImgBox url={img.image_url} style={{ marginTop: 4 }} />
                </div>
            );
        }

        if (isInserted) {
            if (side !== 'right') return null;

            return (
                <div key={index} className="ins-span">
                    <ImgBox url={img.image_url} style={{ marginTop: 4 }} />
                </div>
            );
        }

        return <ImgBox key={index} url={img.image_url} style={{ marginTop: 4 }} />;
    }

    // ── table block ───────────────────────────────────────────
    if (block.type === 'table') {
        return <NestedTable key={index} table={block.payload} />;
    }

    return null;
}

// ── Check inserted đã có trong content_blocks chưa ────────────
function hasParagraphBlock(blocks, para) {
    if (!para?.uid) return false;

    return (blocks || []).some(b =>
        b.type === 'paragraph' && b.payload?.uid === para.uid
    );
}

function hasImageBlock(blocks, img) {
    const key = getImageKey(img);
    if (!key) return false;

    return (blocks || []).some(b => {
        if (b.type === 'image') {
            return getImageKey(b.payload) === key;
        }

        if (b.type === 'paragraph') {
            return (b.payload?.images || []).some(x => sameImage(x, img));
        }

        return false;
    });
}

// ── CellContent — render LogicalCell CÓ diff ─────────────────
export function CellContent({ cellChange, side, cell = null, cellNode = null, fallback = '' }) {
    const node = cell ?? cellNode;

    if (!cellChange) {
        return <CellNode cell={node} fallbackText={fallback || getCellText(node)} />;
    }

    const changes = cellChange.changes || [];

    // span_changed: tìm paragraph_modified đầu tiên
    if (cellChange.type === 'table_cell_span_changed') {
        for (const ch of changes) {
            if (ch.type === 'paragraph_modified') {
                return <WordDiff wd={ch} side={side} />;
            }
        }

        const txt = side === 'left'
            ? (cellChange.left_text || '')
            : (cellChange.right_text || '');

        return <>{txt}</>;
    }

    // Không có changes → render cell bình thường
    if (!changes.length) {
        return <CellNode cell={node} fallbackText={fallback || getCellText(node)} />;
    }

    // Có nested table changes → fallback về logic cũ
    const hasNestedChanges = changes.some(ch =>
        ['nested_table_modified', 'nested_table_to_text', 'text_to_nested_table'].includes(ch.type)
    );

    if (hasNestedChanges) {
        return (
            <LegacyCellContent
                cellChange={cellChange}
                side={side}
                node={node}
                fallback={fallback}
            />
        );
    }

    const sideCell = side === 'left'
        ? (cellChange.left_cell ?? node)
        : (cellChange.right_cell ?? node);

    const maps = buildChangeMaps(changes);
    const blocks = sideCell?.content_blocks || [];

    if (blocks.length) {
        const rendered = blocks
            .map((block, i) => renderBlock({ block, index: i, side, maps }))
            .filter(Boolean);

        // Nếu backend chưa đưa inserted vào right_cell.content_blocks thì append thêm
        if (side === 'right') {
            for (const para of maps.insertedParas) {
                if (!hasParagraphBlock(blocks, para)) {
                    const txt = para.text_display || para.text || '';

                    rendered.push(
                        <div key={`ins-p-${para.uid || rendered.length}`}>
                            {txt && <span className="ins-span">{txt}</span>}
                            {renderParagraphImages(para.images || [], side, maps)}
                        </div>
                    );
                }
            }

            for (const img of maps.insertedImgs) {
                if (!hasImageBlock(blocks, img) && img?.image_url) {
                    rendered.push(
                        <div key={`ins-img-${getImageKey(img) || rendered.length}`} className="ins-span">
                            <ImgBox url={img.image_url} style={{ marginTop: 4 }} />
                        </div>
                    );
                }
            }
        }

        if (rendered.length) return <>{rendered}</>;
    }

    return (
        <LegacyCellContent
            cellChange={cellChange}
            side={side}
            node={node}
            fallback={fallback}
        />
    );
}

// ── LegacyCellContent — fallback cho nested/edge case ─────────
function LegacyCellContent({ cellChange, side, node, fallback }) {
    const changes = cellChange.changes || [];
    const parts = [];

    for (const ch of changes) {
        const t = ch.type || '';

        if (t === 'paragraph_modified') {
            const paraNode = side === 'left' ? ch.original : ch.modified;

            parts.push(
                <div key={parts.length}>
                    <WordDiff wd={ch} side={side} />
                    {(paraNode?.images || []).map((img, i) =>
                        img.image_url
                            ? <ImgBox key={i} url={img.image_url} style={{ marginTop: 4 }} />
                            : null
                    )}
                </div>
            );

            continue;
        }

        if (t === 'paragraph_unchanged') {
            const para = side === 'left' ? ch.original : ch.modified;

            if (para) {
                const txt = para.text_display || para.text || '';

                parts.push(
                    <div key={parts.length}>
                        {txt && <span>{txt}</span>}
                        {(para.images || []).map((img, i) =>
                            img.image_url
                                ? <ImgBox key={i} url={img.image_url} style={{ marginTop: 4 }} />
                                : null
                        )}
                    </div>
                );
            }

            continue;
        }

        if (t === 'paragraph_inserted' && side === 'right') {
            const para = ch.modified;

            if (para) {
                const txt = para.text_display || para.text || '';

                parts.push(
                    <div key={parts.length}>
                        {txt && <span className="ins-span">{txt}</span>}
                        {(para.images || []).map((img, i) =>
                            img.image_url
                                ? <div key={i} className="ins-span">
                                    <ImgBox url={img.image_url} style={{ marginTop: 4 }} />
                                </div>
                                : null
                        )}
                    </div>
                );
            }

            continue;
        }

        if (t === 'paragraph_deleted' && side === 'left') {
            const para = ch.original;

            if (para) {
                const txt = para.text_display || para.text || '';

                parts.push(
                    <div key={parts.length}>
                        {txt && <span className="del-span">{txt}</span>}
                        {(para.images || []).map((img, i) =>
                            img.image_url
                                ? <div key={i} className="del-span">
                                    <ImgBox url={img.image_url} style={{ marginTop: 4 }} />
                                </div>
                                : null
                        )}
                    </div>
                );
            }

            continue;
        }

        if (t === 'image_unchanged') {
            const img = side === 'left' ? ch.original : ch.modified;

            if (img?.image_url) {
                parts.push(
                    <ImgBox
                        key={parts.length}
                        url={img.image_url}
                        style={{ marginTop: 4 }}
                    />
                );
            }

            continue;
        }

        if (t === 'image_modified') {
            const img = side === 'left' ? ch.original : ch.modified;

            if (img?.image_url) {
                parts.push(
                    <div
                        key={parts.length}
                        className={side === 'left' ? 'del-span' : 'ins-span'}
                    >
                        <ImgBox url={img.image_url} style={{ marginTop: 4 }} />
                    </div>
                );
            }

            continue;
        }

        if (t === 'image_added' && side === 'right') {
            const img = ch.modified;

            if (img?.image_url) {
                parts.push(
                    <div key={parts.length} className="ins-span">
                        <ImgBox url={img.image_url} style={{ marginTop: 4 }} />
                    </div>
                );
            }

            continue;
        }

        if (t === 'image_deleted' && side === 'left') {
            const img = ch.original;

            if (img?.image_url) {
                parts.push(
                    <div key={parts.length} className="del-span">
                        <ImgBox url={img.image_url} style={{ marginTop: 4 }} />
                    </div>
                );
            }

            continue;
        }

        if (t === 'nested_table_unchanged') {
            const tbl = side === 'left' ? ch.original : ch.modified;

            parts.push(
                <div key={parts.length}>
                    <span className="nested-tbl-badge eq-badge">
                        = Nested table
                    </span>
                    <NestedTable table={tbl} wrapClass="nested-eq" />
                </div>
            );

            continue;
        }

        if (t === 'nested_table_modified') {
            parts.push(
                <div key={parts.length}>
                    <span className="nested-tbl-badge mod-badge">
                        ≈ Nested table (sửa)
                    </span>
                    <NestedTableWithDiff nestedChange={ch} side={side} />
                </div>
            );

            continue;
        }

        if (t === 'nested_table_to_text') {
            if (side === 'left') {
                parts.push(
                    <div key={parts.length}>
                        <span className="nested-tbl-badge del-badge">
                            - Nested table
                        </span>
                        <NestedTable table={ch.original_table} wrapClass="nested-del" />
                    </div>
                );
            } else {
                const txt = ch.new_text || '';

                if (txt) {
                    parts.push(
                        <div key={parts.length}>
                            <span className="ins-span">{txt}</span>
                        </div>
                    );
                }
            }

            continue;
        }

        if (t === 'text_to_nested_table') {
            if (side === 'left') {
                const txt = ch.old_text || '';

                if (txt) {
                    parts.push(
                        <div key={parts.length}>
                            <span className="del-span">{txt}</span>
                        </div>
                    );
                }
            } else {
                parts.push(
                    <div key={parts.length}>
                        <span className="nested-tbl-badge ins-badge">
                            + Nested table
                        </span>
                        <NestedTable table={ch.modified_table} wrapClass="nested-ins" />
                    </div>
                );
            }

            continue;
        }
    }

    if (!parts.length) {
        return <CellNode cell={node} fallbackText={fallback || getCellText(node)} />;
    }

    return <>{parts}</>;
}
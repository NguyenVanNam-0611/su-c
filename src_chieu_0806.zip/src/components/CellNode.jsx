﻿// ─────────────────────────────────────────────────────────────
// CellNode.jsx  — render LogicalCell không có diff
// ─────────────────────────────────────────────────────────────
// Schema cell:
//   paragraphs: [{ uid, text, text_display, images: [{image_url,...}] }]
//   images:     [image_url, ...]          (flat url list — quick access)
//   image_details: [{uid, image_url, ...}]
//   nested_table: LogicalTable | null

import { ImgBox } from './WordDiff';
import { NestedTable } from './NestedTable';

export function CellNode({ cell, fallbackText = '' }) {
    if (!cell) return <>{fallbackText}</>;

    const { paragraphs = [], images = [], nested_table } = cell;

    // ── Nested table ──────────────────────────────────────────
    if (nested_table) {
        return (
            <div>
                {paragraphs.map(p => {
                    const txt = p.text_display || p.text || '';
                    return txt ? <div key={p.uid}>{txt}</div> : null;
                })}
                <NestedTable table={nested_table} />
            </div>
        );
    }

    // ── Paragraphs + inline images ────────────────────────────
    if (paragraphs.length) {
        return (
            <>
                {paragraphs.map(p => {
                    const txt = p.text_display || p.text || '';
                    const imgs = p.images || [];
                    return (
                        <div key={p.uid}>
                            {txt && <span>{txt}</span>}
                            {imgs.map((img, i) =>
                                img.image_url
                                    ? <ImgBox key={i} url={img.image_url} style={{ marginTop: 4 }} />
                                    : null
                            )}
                        </div>
                    );
                })}
                {/* Cell-level images (không thuộc paragraph nào) */}
                {images.map((url, i) =>
                    url ? <ImgBox key={`ci-${i}`} url={url} style={{ marginTop: 4 }} /> : null
                )}
            </>
        );
    }

    // ── Fallback: text_display hoặc fallbackText ──────────────
    const txt = cell.text_display || cell.text || fallbackText;
    return (
        <>
            {txt && <span>{txt}</span>}
            {images.map((url, i) =>
                url ? <ImgBox key={i} url={url} style={{ marginTop: 4 }} /> : null
            )}
        </>
    );
}
﻿export default function Footer() {
    return (
        <footer className="pb-6 text-center mt-auto">
            <p className="text-xs text-slate-600 font-medium">
                Designed by IT Section • 2026
            </p>
        </footer>
    );
}
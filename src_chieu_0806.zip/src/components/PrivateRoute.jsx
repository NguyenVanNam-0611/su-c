﻿import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

// ✅ requiredRole không bắt buộc — nếu không truyền thì chỉ cần đăng nhập
export default function PrivateRoute({ children, requiredRole }) {
    const { user } = useAuth();

    // Chưa đăng nhập → về login
    if (!user) return <Navigate to="/login" replace />;

    // Sai role → về trang của mình
    if (requiredRole && user.role !== requiredRole) {
        return <Navigate to={user.role === 'Admin' ? '/admin' : '/upload'} replace />;
    }

    return children;
}
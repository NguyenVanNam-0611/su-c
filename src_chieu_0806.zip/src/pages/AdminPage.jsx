﻿import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import api from '../api/api';
import Header from '../components/Header';
import Footer from '../components/Footer';

export default function AdminPage() {
    const { user } = useAuth();
    const navigate = useNavigate();

    // Bấm Back trình duyệt → về login
    useEffect(() => {
        window.history.pushState(null, '', window.location.href);
        const handlePopState = () => navigate('/login', { replace: true });
        window.addEventListener('popstate', handlePopState);
        return () => window.removeEventListener('popstate', handlePopState);
    }, []);

    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');

    // Form tạo user
    const [showForm, setShowForm] = useState(false);
    const [newUser, setNewUser] = useState({ username: '', password: '', roleId: 2 });
    const [formError, setFormError] = useState('');
    const [formLoading, setFormLoading] = useState(false);

    // Tìm kiếm
    const [search, setSearch] = useState('');

    // Đổi mật khẩu
    const [changePwdId, setChangePwdId] = useState(null); // id đang mở modal
    const [newPassword, setNewPassword] = useState('');
    const [pwdError, setPwdError] = useState('');
    const [pwdLoading, setPwdLoading] = useState(false);
    const [pwdSuccess, setPwdSuccess] = useState('');

    const fetchUsers = async () => {
        try {
            setLoading(true);
            const { data } = await api.get('/admin/users');
            setUsers(data);
        } catch {
            setError('Không thể tải danh sách người dùng');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => { fetchUsers(); }, []);

    const filteredUsers = users.filter(u =>
        u.username.toLowerCase().includes(search.toLowerCase())
    );

    const handleToggle = async (id) => {
        try {
            const { data } = await api.patch(`/admin/users/${id}/toggle`);
            setUsers(prev => prev.map(u =>
                u.id === id ? { ...u, isActive: data.isActive } : u
            ));
        } catch {
            setError('Không thể thay đổi trạng thái tài khoản');
        }
    };

    const handleDelete = async (id, username) => {
        if (!window.confirm(`Xóa tài khoản "${username}"?`)) return;
        try {
            await api.delete(`/admin/users/${id}`);
            setUsers(prev => prev.filter(u => u.id !== id));
        } catch {
            setError('Không thể xóa tài khoản');
        }
    };

    const handleCreateUser = async () => {
        if (!newUser.username.trim() || !newUser.password.trim()) {
            setFormError('Vui lòng nhập đủ thông tin'); return;
        }
        setFormError(''); setFormLoading(true);
        try {
            await api.post('/admin/users', newUser);
            setNewUser({ username: '', password: '', roleId: 2 });
            setShowForm(false);
            await fetchUsers();
        } catch (err) {
            setFormError(err.response?.data?.message || 'Tạo tài khoản thất bại');
        } finally {
            setFormLoading(false);
        }
    };

    const openChangePwd = (id) => {
        setChangePwdId(id);
        setNewPassword('');
        setPwdError('');
        setPwdSuccess('');
    };

    const closeChangePwd = () => {
        setChangePwdId(null);
        setNewPassword('');
        setPwdError('');
        setPwdSuccess('');
    };

    const handleChangePassword = async () => {
        if (!newPassword.trim() || newPassword.length < 6) {
            setPwdError('Mật khẩu phải có ít nhất 6 ký tự'); return;
        }
        setPwdError(''); setPwdLoading(true);
        try {
            await api.patch(`/admin/users/${changePwdId}/password`, { newPassword });
            setPwdSuccess('Đổi mật khẩu thành công!');
            setTimeout(() => closeChangePwd(), 1200);
        } catch (err) {
            setPwdError(err.response?.data?.message || 'Đổi mật khẩu thất bại');
        } finally {
            setPwdLoading(false);
        }
    };

    return (
        <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-green-100 to-green-200 flex flex-col">

            <Header />

            <main className="flex-1 p-6 lg:p-8 max-w-[1200px] mx-auto w-full flex flex-col gap-6">

                {/* TOOLBAR */}
                <div className="flex items-center justify-between gap-3 flex-wrap">
                    <div>
                        <h2 className="text-xl font-bold text-slate-800">Quản lý người dùng</h2>
                        <p className="text-sm text-slate-500 mt-0.5">
                            Hiển thị: {filteredUsers.length} / {users.length} tài khoản
                        </p>
                    </div>
                    <div className="flex items-center gap-2 flex-wrap">
                        {/* Ô tìm kiếm */}
                        <div className="relative">
                            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-sm">🔍</span>
                            <input
                                type="text"
                                placeholder="Tìm tên đăng nhập..."
                                value={search}
                                onChange={e => setSearch(e.target.value)}
                                className="pl-9 pr-4 py-2 text-sm border border-gray-200 rounded-full bg-white/80 focus:outline-none focus:ring-2 focus:ring-green-300 w-52"
                            />
                            {search && (
                                <button
                                    onClick={() => setSearch('')}
                                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs"
                                >✕</button>
                            )}
                        </div>
                        <button
                            onClick={() => setShowForm(!showForm)}
                            className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white text-sm font-semibold px-4 py-2 rounded-full shadow transition"
                        >
                            {showForm ? '✕ Đóng' : '+ Tạo tài khoản'}
                        </button>
                    </div>
                </div>

                {/* FORM TẠO USER */}
                {showForm && (
                    <div className="bg-white/90 backdrop-blur-xl rounded-2xl border border-green-200 p-6 shadow-sm">
                        <h3 className="text-base font-bold text-slate-700 mb-4">Tạo tài khoản mới</h3>
                        {formError && <p className="text-sm text-red-500 mb-3">{formError}</p>}
                        <div className="flex flex-wrap gap-3">
                            <input
                                className="flex-1 min-w-[150px] border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-green-300"
                                placeholder="Tên đăng nhập"
                                value={newUser.username}
                                onChange={e => setNewUser(p => ({ ...p, username: e.target.value }))}
                            />
                            <input
                                className="flex-1 min-w-[150px] border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-green-300"
                                type="password"
                                placeholder="Mật khẩu"
                                value={newUser.password}
                                onChange={e => setNewUser(p => ({ ...p, password: e.target.value }))}
                            />
                            <select
                                className="border border-gray-200 rounded-xl px-4 py-2.5 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-green-300"
                                value={newUser.roleId}
                                onChange={e => setNewUser(p => ({ ...p, roleId: Number(e.target.value) }))}
                            >
                                <option value={2}>User</option>
                                <option value={1}>Admin</option>
                            </select>
                            <button
                                onClick={handleCreateUser}
                                disabled={formLoading}
                                className="bg-green-600 hover:bg-green-700 text-white text-sm font-semibold px-6 py-2.5 rounded-xl transition disabled:opacity-70"
                            >
                                {formLoading ? 'Đang tạo...' : 'Tạo'}
                            </button>
                        </div>
                    </div>
                )}

                {error && <p className="text-sm text-red-500">{error}</p>}

                {/* TABLE */}
                <div className="bg-white/90 backdrop-blur-xl rounded-2xl border border-white/60 shadow-sm overflow-hidden">
                    {loading ? (
                        <p className="text-center text-slate-400 py-12">Đang tải...</p>
                    ) : (
                        <table className="w-full text-sm">
                            <thead>
                                <tr className="bg-green-50 border-b border-green-100">
                                    <th className="px-4 py-3 text-left font-semibold text-slate-600">ID</th>
                                    <th className="px-4 py-3 text-left font-semibold text-slate-600">Tên đăng nhập</th>
                                    <th className="px-4 py-3 text-left font-semibold text-slate-600">Role</th>
                                    <th className="px-4 py-3 text-left font-semibold text-slate-600">Ngày tạo</th>
                                    <th className="px-4 py-3 text-left font-semibold text-slate-600">Trạng thái</th>
                                    <th className="px-4 py-3 text-left font-semibold text-slate-600">Hành động</th>
                                </tr>
                            </thead>
                            <tbody>
                                {filteredUsers.length === 0 ? (
                                    <tr>
                                        <td colSpan={6} className="text-center text-slate-400 py-10">
                                            Không tìm thấy tài khoản nào
                                        </td>
                                    </tr>
                                ) : filteredUsers.map((u, i) => (
                                    <tr
                                        key={u.id}
                                        className={`border-b border-gray-50 ${i % 2 === 0 ? 'bg-white' : 'bg-slate-50/50'} hover:bg-green-50/40 transition`}
                                    >
                                        <td className="px-4 py-3 text-slate-400">{u.id}</td>
                                        <td className="px-4 py-3 font-semibold text-slate-700">{u.username}</td>
                                        <td className="px-4 py-3">
                                            <span className={`px-2.5 py-1 rounded-full text-xs font-semibold ${u.role === 'Admin' ? 'bg-amber-100 text-amber-700' : 'bg-blue-100 text-blue-600'}`}>
                                                {u.role}
                                            </span>
                                        </td>
                                        <td className="px-4 py-3 text-slate-500">
                                            {new Date(u.createdAt).toLocaleDateString('vi-VN')}
                                        </td>
                                        <td className="px-4 py-3">
                                            <span className={`px-2.5 py-1 rounded-full text-xs font-semibold ${u.isActive ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-500'}`}>
                                                {u.isActive ? '● Hoạt động' : '● Đã khóa'}
                                            </span>
                                        </td>
                                        <td className="px-4 py-3">
                                            <div className="flex items-center gap-2 flex-wrap">
                                                {/* Khóa / Mở khóa */}
                                                <button
                                                    onClick={() => handleToggle(u.id)}
                                                    className={`text-xs font-semibold px-3 py-1.5 rounded-lg transition ${u.isActive ? 'bg-amber-100 text-amber-700 hover:bg-amber-200' : 'bg-green-100 text-green-700 hover:bg-green-200'}`}
                                                >
                                                    {u.isActive ? 'Khóa' : 'Mở khóa'}
                                                </button>

                                                {/* Đổi mật khẩu */}
                                                <button
                                                    onClick={() => openChangePwd(u.id)}
                                                    className="text-xs font-semibold px-3 py-1.5 rounded-lg bg-indigo-100 text-indigo-600 hover:bg-indigo-200 transition"
                                                >
                                                    Đổi MK
                                                </button>

                                                {/* Xóa */}
                                                {u.username !== user?.username && (
                                                    <button
                                                        onClick={() => handleDelete(u.id, u.username)}
                                                        className="text-xs font-semibold px-3 py-1.5 rounded-lg bg-red-100 text-red-500 hover:bg-red-200 transition"
                                                    >
                                                        Xóa
                                                    </button>
                                                )}
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    )}
                </div>
            </main>

            <Footer />

            {/* MODAL ĐỔI MẬT KHẨU */}
            {changePwdId !== null && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm">
                    <div className="bg-white rounded-2xl shadow-2xl p-6 w-full max-w-sm mx-4">
                        <h3 className="text-base font-bold text-slate-800 mb-1">Đổi mật khẩu</h3>
                        <p className="text-sm text-slate-400 mb-4">
                            Tài khoản: <span className="font-semibold text-slate-600">
                                {users.find(u => u.id === changePwdId)?.username}
                            </span>
                        </p>

                        {pwdError && (
                            <p className="text-sm text-red-500 mb-3">{pwdError}</p>
                        )}
                        {pwdSuccess && (
                            <p className="text-sm text-green-600 mb-3 font-semibold">{pwdSuccess}</p>
                        )}

                        <input
                            type="password"
                            placeholder="Mật khẩu mới (tối thiểu 6 ký tự)"
                            value={newPassword}
                            onChange={e => setNewPassword(e.target.value)}
                            onKeyDown={e => e.key === 'Enter' && handleChangePassword()}
                            className="w-full border border-gray-200 rounded-xl px-4 py-2.5 text-sm mb-4 focus:outline-none focus:ring-2 focus:ring-indigo-300"
                        />

                        <div className="flex gap-2 justify-end">
                            <button
                                onClick={closeChangePwd}
                                className="text-sm px-4 py-2 rounded-lg bg-gray-100 text-slate-600 hover:bg-gray-200 transition"
                            >
                                Hủy
                            </button>
                            <button
                                onClick={handleChangePassword}
                                disabled={pwdLoading}
                                className="text-sm font-semibold px-5 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white transition disabled:opacity-70"
                            >
                                {pwdLoading ? 'Đang lưu...' : 'Xác nhận'}
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}
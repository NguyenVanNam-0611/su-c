﻿import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../api/api';
import { useAuth } from '../context/AuthContext';
import '../css/LoginPage.css';
import Footer from '../components/Footer';

export default function LoginPage() {

    const [form, setForm] = useState({
        username: '',
        password: ''
    });

    const [error, setError] = useState('');
    const [showError, setShowError] = useState(false);
    const [loading, setLoading] = useState(false);
    const [showPassword, setShowPassword] = useState(false);

    const { login } = useAuth();
    const navigate = useNavigate();

    const handleChange = (e) => {
        setForm(prev => ({
            ...prev,
            [e.target.name]: e.target.value
        }));
    };

    const handleKeyDown = (e) => {
        if (e.key === 'Enter') handleSubmit();
    };

    const openErrorPopup = (message) => {
        setError(message);
        setShowError(true);
        setLoading(false);
    };

    const handleSubmit = async () => {

        setError('');
        setShowError(false);

        if (!form.username.trim() || !form.password.trim()) {
            openErrorPopup('Vui lòng nhập đầy đủ thông tin');
            return;
        }

        setLoading(true);

        try {

            const response = await api.post('/auth/login', form);
            const data = response.data;

            if (data?.success === false || data?.token === null || data?.token === undefined) {
                openErrorPopup(data?.message || 'Sai tên đăng nhập hoặc mật khẩu');
                return;
            }

            login(data);

            navigate(
                data.role === 'Admin' ? '/admin' : '/upload',
                { replace: true }
            );

        } catch (err) {
            openErrorPopup(
                err.response?.data?.message ||
                err.message ||
                'Sai tên đăng nhập hoặc mật khẩu'
            );
        }
    };

    return (

        <div className="login-page">

            <main className="login-main">

                <div className="login-wrapper">

                    {/* HEADER */}
                    <div className="login-header">
                        <img
                            src="/logo_terumo.png"
                            alt="Terumo Logo"
                            className="login-logo"
                        />
                        <h1 className="login-title">
                            Text Comparison Tool
                        </h1>
                        <p className="login-subtitle">
                            Hệ thống đối soát tài liệu nội bộ
                        </p>
                    </div>

                    {/* CARD */}
                    <div className="login-card">
                        <div className="login-form">

                            {/* USERNAME */}
                            <div className="login-group">
                                <label className="login-label">
                                    Tên đăng nhập
                                </label>
                                <input
                                    name="username"
                                    type="text"
                                    placeholder="Nhập tên đăng nhập"
                                    value={form.username}
                                    onChange={handleChange}
                                    onKeyDown={handleKeyDown}
                                    className="login-input"
                                />
                            </div>

                            {/* PASSWORD */}
                            <div className="login-group">
                                <label className="login-label">
                                    Mật khẩu
                                </label>
                                <div className="password-wrapper">
                                    <input
                                        name="password"
                                        type={showPassword ? 'text' : 'password'}
                                        placeholder="Nhập mật khẩu"
                                        value={form.password}
                                        onChange={handleChange}
                                        onKeyDown={handleKeyDown}
                                        className="login-input password-input"
                                        autoComplete="new-password"
                                    />
                                    <button
                                        type="button"
                                        onClick={() => setShowPassword(!showPassword)}
                                        className="password-toggle"
                                    >
                                        {showPassword ? '🙈' : '👁️'}
                                    </button>
                                </div>
                            </div>

                            {/* BUTTON */}
                            <button
                                type="button"
                                onClick={handleSubmit}
                                disabled={loading}
                                className="login-button"
                            >
                                {loading ? 'Đang đăng nhập...' : 'Đăng nhập'}
                            </button>

                        </div>
                    </div>

                </div>

            </main>

            {/* FOOTER */}
            <Footer />

            {/* ERROR POPUP */}
            {showError && (
                <div className="error-overlay">
                    <div className="error-popup">
                        <button
                            type="button"
                            onClick={() => setShowError(false)}
                            className="error-close"
                        >
                            ✕
                        </button>
                        <div className="error-icon-wrapper">
                            <span className="error-icon">⚠️</span>
                        </div>
                        <h2 className="error-title">
                            Đăng nhập thất bại
                        </h2>
                        <p className="error-message">
                            {error}
                        </p>
                        <button
                            type="button"
                            onClick={() => setShowError(false)}
                            className="error-button"
                        >
                            Đã hiểu
                        </button>
                    </div>
                </div>
            )}

        </div>
    );
}
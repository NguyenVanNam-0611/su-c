﻿// ─────────────────────────────────────────────────────────────
// diffHelpers.js
// ─────────────────────────────────────────────────────────────

export function esc(s) {
    if (s == null) return '';
    return String(s)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

/**
 * Extract display text từ LogicalCell hoặc DocNode cell.
 * Priority: text_display → text → join paragraphs → walk children
 */
export function getCellText(cell) {
    if (!cell) return '';

    const direct = cell.text_display ?? cell.text;
    if (direct) return direct;

    // LogicalCell: paragraphs[]
    const paras = cell.paragraphs || [];
    if (paras.length) {
        const parts = paras
            .map(p => (p.text_display ?? p.text ?? '').trim())
            .filter(Boolean);
        if (parts.length) return parts.join('\n');
    }

    // DocNode cell: children[]
    const children = cell.children || [];
    const paraTexts = children
        .filter(ch => ch?.type === 'paragraph')
        .map(ch => ((ch.content && (ch.content.text_display ?? ch.content.text)) || '').trim())
        .filter(Boolean);
    if (paraTexts.length) return paraTexts.join('\n');

    return '';
}

/**
 * Lấy image URLs từ LogicalCell hoặc DocNode cell.
 */
export function getCellImages(cell) {
    if (!cell) return [];

    // LogicalCell: cell.images là [url, url, ...]
    if (Array.isArray(cell.images) && cell.images.length) {
        return cell.images.filter(Boolean);
    }

    // Fallback: collect từ paragraphs[].images[]
    const urls = [];
    for (const p of (cell.paragraphs || [])) {
        for (const img of (p.images || [])) {
            if (img?.image_url) urls.push(img.image_url);
        }
    }

    // DocNode: walk children
    for (const ch of (cell.children || [])) {
        if (!ch) continue;
        if (ch.type === 'image') {
            const url = ch.image_url || ch.image?.image_url || ch.content?.image_url;
            if (url) urls.push(url);
        }
        if (ch.type === 'paragraph') {
            for (const img of (ch.children || [])) {
                if (img?.type === 'image') {
                    const url = img.image_url || img.image?.image_url || img.content?.image_url;
                    if (url) urls.push(url);
                }
            }
        }
    }
    return urls;
}

export function getAllCellImages(cell) {
    if (!cell) return [];
    const seen = new Set();
    const urls = [];

    const push = url => {
        if (url && !seen.has(url)) { seen.add(url); urls.push(url); }
    };

    // LogicalCell
    (cell.images || []).forEach(push);
    for (const img of (cell.image_details || [])) push(img?.image_url);
    for (const p of (cell.paragraphs || [])) {
        for (const img of (p.images || [])) push(img?.image_url);
    }

    // DocNode
    for (const ch of (cell.children || [])) {
        if (!ch) continue;
        if (ch.type === 'image') push(ch.image_url || ch.image?.image_url || ch.content?.image_url);
        if (ch.type === 'paragraph') {
            for (const img of (ch.children || [])) {
                if (img?.type === 'image') push(img.image_url || img.image?.image_url || img.content?.image_url);
            }
        }
    }
    return urls;
}

/**
 * buildWordDiffParts — render word diff spans cho 1 side
 */
export function buildWordDiffParts(wd, side) {
    if (!wd) return [{ type: 'empty' }];

    const spans = wd.spans;
    if (!spans || !Array.isArray(spans) || spans.length === 0) {
        const txt = side === 'left' ? (wd.old_full_text || '') : (wd.new_full_text || '');
        return txt ? [{ type: 'text', text: txt }] : [{ type: 'empty' }];
    }

    const parts = [];
    for (const s of spans) {
        if (s.type === 'newline') {
            parts.push({ type: 'newline', spaceBefore: false });
            continue;
        }
        if (s.type === 'delete' && side !== 'left') continue;
        if (s.type === 'insert' && side !== 'right') continue;

        const spaceBefore = s.space_before === true;
        const txt = side === 'left'
            ? (s.old_text ?? s.text ?? '')
            : (s.new_text ?? s.text ?? '');
        if (!txt && s.type !== 'replace') continue;

        if (s.type === 'equal') {
            parts.push({ type: 'text', text: txt, spaceBefore });
        } else if (s.type === 'delete') {
            parts.push({ type: 'delete', text: txt, spaceBefore });
        } else if (s.type === 'insert') {
            parts.push({ type: 'insert', text: txt, spaceBefore });
        } else if (s.type === 'replace') {
            const text = side === 'left' ? (s.old_text || '') : (s.new_text || '');
            parts.push({ type: side === 'left' ? 'delete' : 'insert', text, spaceBefore });
        }
    }
    return parts.length ? parts : [{ type: 'empty' }];
}

/**
 * Convert DocNode table tree → { rows } format dùng bởi FullTable renderer.
 * Fallback khi không có full_table_original/modified từ backend.
 */
export function nodeToTableData(node) {
    if (!node) return null;
    const rows = (node.children || [])
        .filter(r => r?.type === 'row')
        .map(r => ({
            row_index: r.content?.row_index ?? 0,
            cells: (r.children || [])
                .filter(c => c?.type === 'cell')
                .map(c => ({
                    col_index: c.content?.col_index ?? 0,
                    row_index: c.content?.row_index ?? 0,
                    col_span: c.content?.col_span ?? 1,
                    row_span: c.content?.row_span ?? 1,
                    text: c.content?.text ?? '',
                    text_display: c.content?.text_display ?? '',
                    children: c.children ?? [],
                }))
        }));
    return { rows };
}
"""
block/table_merge.py

Merge các bảng bị cắt trang thành 1 bảng liên tục.
Tách từ block_builder.py, import bởi block_builder.py.
"""

from __future__ import annotations

from typing import List, Optional

from src.services.models.docnode import DocNode
from src.services.models.block import Block
from src.services.models.logical_table import LogicalCell, LogicalTable
from src.services.block.signature import signature
from src.services.block.filters import _norm, _is_skip_pattern


def _get_logical_table(table_node: DocNode) -> Optional[LogicalTable]:
    return getattr(table_node, "logical_table", None)


def _get_header_key(table_node: DocNode) -> Optional[str]:
    """
    Key từ anchor_row=0. Header toàn rỗng → không đủ tin cậy để match → None.
    """
    lt = _get_logical_table(table_node)
    if lt is None:
        return None
    header_cells = lt.cells_in_row(0)
    if not header_cells:
        return None
    key = "|".join(_norm(c.text) for c in header_cells)
    if not key.replace("|", "").strip():
        return None
    return key


def _last_anchor_row_is_continue(table_node: DocNode) -> bool:
    """
    True nếu visual last row toàn là text kiểu "tiếp trang sau / continued...",
    nghĩa là bảng bị cắt trang và cần merge với bảng tiếp theo.

    Dùng visual last row (max anchor_row + row_span - 1) thay vì
    anchor_rows[-1] để xử lý đúng khi cell cuối có row_span > 1.
    """
    lt = _get_logical_table(table_node)
    if lt is None:
        return False
    if not lt.cells:
        return False

    last_visual_row = max(c.anchor_row + c.row_span - 1 for c in lt.cells)

    cells_at_last = [
        c for c in lt.cells
        if c.anchor_row <= last_visual_row < c.anchor_row + c.row_span
    ]
    non_empty = [_norm(c.text) for c in cells_at_last if _norm(c.text)]
    if not non_empty:
        return False
    return all(_is_skip_pattern(t) for t in non_empty)


def _remove_last_anchor_row(lt: LogicalTable) -> None:
    """
    Xoá tất cả cell occupy visual last row, recalculate total_rows.

    Dùng visual last row (max anchor_row + row_span - 1) thay vì
    anchor_rows[-1]: một cell "Tiếp trang sau" với row_span > 1 có
    anchor_row nhỏ hơn row cuối nó occupy, nên filter theo anchor_row
    cuối sẽ không xoá được cell này.
    """
    if not lt.cells:
        return

    last_visual_row = max(c.anchor_row + c.row_span - 1 for c in lt.cells)

    lt.cells = [
        c for c in lt.cells
        if not (c.anchor_row <= last_visual_row < c.anchor_row + c.row_span)
    ]

    lt.total_rows = max(c.anchor_row + c.row_span for c in lt.cells) if lt.cells else 0


def _count_repeated_header_rows(
    base_lt: LogicalTable,
    extra_lt: LogicalTable,
) -> int:
    """
    Đếm bao nhiêu rows đầu của extra_lt trùng với base_lt theo thứ tự.

    Document SOP Nhật thường có 1-2 header rows lặp lại ở mỗi trang
    (header chính + subheader chi tiết). So sánh từng row từ đầu,
    dừng khi gặp row không khớp; row rỗng ở cả hai bên được bỏ qua
    (không tính, không dừng).
    """
    base_anchor_rows  = base_lt.anchor_rows()
    extra_anchor_rows = extra_lt.anchor_rows()

    count = 0
    for base_r, extra_r in zip(base_anchor_rows, extra_anchor_rows):
        base_key  = "|".join(_norm(c.text) for c in base_lt.cells_in_row(base_r))
        extra_key = "|".join(_norm(c.text) for c in extra_lt.cells_in_row(extra_r))

        base_stripped  = base_key.replace("|", "").strip()
        extra_stripped = extra_key.replace("|", "").strip()
        if not base_stripped and not extra_stripped:
            continue

        if base_key == extra_key and base_stripped:
            count += 1
        else:
            break

    return count


def _normalize_col_span(
    cell: LogicalCell,
    extra_lt: LogicalTable,
    base_total_cols: int,
) -> int:
    """
    Nếu cell là cell cuối cùng theo chiều ngang trong extra, kéo col_span
    đến hết total_cols của base — xử lý trường hợp grid của extra ít cột
    hơn base (vd: base có subheader tách cột, extra không có).

    Kết quả có thể vượt biên hoặc âm; clamp thực hiện ở _merge_logical_tables
    sau khi đã drop các cell out-of-bounds.
    """
    body_cells = [c for c in extra_lt.cells if c.anchor_row > 0]
    if not body_cells:
        return cell.col_span
    extra_max_col = max(c.anchor_col for c in body_cells)
    if cell.anchor_col == extra_max_col:
        return base_total_cols - cell.anchor_col
    return cell.col_span


def _merge_logical_tables(
    base_lt: LogicalTable,
    extra_lt: LogicalTable,
) -> None:
    """
    Merge toàn bộ cells của extra_lt vào base_lt.

    Cell có anchor_col >= base_total_cols bị drop: artifact khi extra có
    subheader làm lệch grid so với base, không có vị trí hợp lệ trong base
    grid (nếu giữ sẽ sinh gridColumn vượt biên, vỡ CSS Grid ở frontend).

    col_span được clamp vào [1, base_total_cols - anchor_col] để tránh
    âm hoặc tràn ra ngoài grid.
    """
    skip_count      = _count_repeated_header_rows(base_lt, extra_lt)
    offset          = base_lt.total_rows
    base_total_cols = base_lt.total_cols

    extra_anchor_rows = extra_lt.anchor_rows()
    skip_rows = set(extra_anchor_rows[:skip_count])

    for cell in extra_lt.cells:
        if cell.anchor_row in skip_rows:
            continue

        if cell.anchor_col >= base_total_cols:
            continue

        col_span = _normalize_col_span(cell, extra_lt, base_total_cols)
        remaining = base_total_cols - cell.anchor_col
        col_span  = max(1, min(col_span, remaining))

        # trừ skip_count để không có gap giữa data rows cuối base và đầu extra
        new_anchor_row = cell.anchor_row + offset - skip_count

        base_lt.cells.append(LogicalCell(
            uid            = cell.uid,
            anchor_row     = new_anchor_row,
            anchor_col     = cell.anchor_col,
            row_span       = cell.row_span,
            col_span       = col_span,
            text           = cell.text,
            text_display   = cell.text_display,
            content_blocks = list(cell.content_blocks),
        ))

    if base_lt.cells:
        base_lt.total_rows = max(c.anchor_row + c.row_span for c in base_lt.cells)


def _merge_spanning_cells(lt: LogicalTable) -> None:
    """
    Gộp các cell định danh bị split do Word cắt trang.

    Word không encode cross-page rowspan trong OOXML, nên cell định danh
    như "5.8.1 Kiểm tra kết dính chuỗi" bị cắt thành 2 cell ở 2 <w:tbl>
    khác nhau. Sau merge, 2 cell này liền kề về anchor_row nhưng vẫn là
    2 cell riêng → frontend render 2 cell thay vì 1 cell spanning.

    Điều kiện gộp A + B:
        - cùng anchor_col, anchor_col <= 1 (chỉ cột định danh như "Mục", "STT";
          cột nội dung dài không gộp vì dễ trùng text do copy header)
        - cùng col_span
        - cùng text (normalized), không rỗng
        - liền kề: A.anchor_row + A.row_span == B.anchor_row

    Không merge content_blocks của B vào A: B là continuation placeholder
    có text trùng A do Word/tool copy lại khi cắt trang — content_blocks
    của B là duplicate, append vào A sẽ render text 2 lần ở frontend.
    Nếu B có nội dung mới thực sự, text(B) != text(A) nên không vào nhánh
    này — đó là 2 cell riêng biệt, không phải split cell.

    Chạy lặp đến khi không còn gì để gộp (handle chain 3+ trang).
    """
    changed = True
    while changed:
        changed = False
        cells_by_col_row = sorted(lt.cells, key=lambda c: (c.anchor_col, c.anchor_row))

        for i in range(len(cells_by_col_row) - 1):
            a = cells_by_col_row[i]
            b = cells_by_col_row[i + 1]

            if (
                a.anchor_col == b.anchor_col
                and a.anchor_col <= 1
                and a.col_span == b.col_span
                and _norm(a.text) and _norm(a.text) == _norm(b.text)
                and a.anchor_row + a.row_span == b.anchor_row
            ):
                a.row_span += b.row_span
                lt.cells.remove(b)
                changed = True
                break  # list đã thay đổi, restart loop

    if lt.cells:
        lt.total_rows = max(c.anchor_row + c.row_span for c in lt.cells)


def _merge_two_tables(base: DocNode, extra: DocNode) -> None:
    """Merge extra vào base ở cả LogicalTable lẫn content dict."""
    base_lt  = _get_logical_table(base)
    extra_lt = _get_logical_table(extra)

    if base_lt is None or extra_lt is None:
        return

    _merge_logical_tables(base_lt, extra_lt)

    base.content["row_count"] = base_lt.total_rows
    base.content["col_count"] = base_lt.total_cols


def _can_merge(prev: Block, curr: Block) -> bool:
    """
    Hai bảng liên tiếp merge được khi cùng type table, header row giống nhau,
    và hàng cuối của prev là "tiếp trang sau..." (continuation signal).

    Không check col_count: dễ lệch do subheader/gridSpan khác nhau giữa
    2 trang dù cùng 1 bảng — header_key match đã đủ chặt.

    Không check heading_ctx: bảng layout nhiều trang dễ lệch heading_ctx
    vì block_builder inject từ heading gần nhất, không đáng tin khi bảng
    chiếm nhiều trang.
    """
    if prev.type != "table" or curr.type != "table":
        return False

    prev_header = _get_header_key(prev.node)
    curr_header = _get_header_key(curr.node)
    if prev_header is None or curr_header is None:
        return False
    if prev_header != curr_header:
        return False

    return True


def merge_consecutive_tables(blocks: List[Block]) -> List[Block]:
    """
    Merge các cặp table liên tiếp bị cắt trang. Chain 3+ bảng được xử lý
    tự nhiên vì sau mỗi lần merge, result[-1] là bảng đã gộp và tiếp tục
    check với bảng kế tiếp.

    Sau khi merge xong, chạy _merge_spanning_cells trên mỗi bảng đã merge
    để gộp cell định danh bị split.
    """
    if not blocks:
        return blocks

    result: List[Block] = []
    merged_indices: set[int] = set()

    for block in blocks:
        if result and _can_merge(result[-1], block):
            prev = result[-1]

            prev_lt = _get_logical_table(prev.node)
            if prev_lt is not None and _last_anchor_row_is_continue(prev.node):
                _remove_last_anchor_row(prev_lt)

            _merge_two_tables(prev.node, block.node)

            prev.signature = signature(prev.node, heading_ctx=prev.heading_ctx or "")

            merged_indices.add(len(result) - 1)
            continue

        result.append(block)

    for idx in merged_indices:
        lt = _get_logical_table(result[idx].node)
        if lt is not None:
            _merge_spanning_cells(lt)
            result[idx].node.content["row_count"] = lt.total_rows

    return result
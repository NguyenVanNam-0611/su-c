"""
diff/image_diff.py

So sánh và serialize image nodes.

image_url là canonical, lưu trong image_block và đọc lại ở top-level
image_payload — đảm bảo 2 nơi luôn nhất quán, không hard-duplicate.

include_data=False (dùng cho ảnh equal) chỉ trả sha256 + metadata, không
có image_url, để frontend không cần render và tiết kiệm bandwidth.
"""

from __future__ import annotations

from typing import Any, Dict, Optional

from src.services.models.docnode import DocNode
from src.services.utils.hash import images_changed


def images_equal(a: Optional[DocNode], b: Optional[DocNode]) -> bool:
    """
    True nếu 2 image node có nội dung giống nhau.

    Tầng 1: sha256 byte-exact — nhanh, không decode ảnh.
    Tầng 2: sha256 khác → load bytes qua image_store rồi so perceptual hash.
    Không đủ dữ liệu để so → conservative, coi là đã thay đổi.
    """
    if a is None and b is None:
        return True
    if a is None or b is None:
        return False
    if a.type != "image" or b.type != "image":
        return False

    a_hash = a.content.get("sha256") or a.content.get("hash")
    b_hash = b.content.get("sha256") or b.content.get("hash")

    if a_hash and b_hash and a_hash == b_hash:
        return True

    a_bytes = _load_image_bytes(a_hash)
    b_bytes = _load_image_bytes(b_hash)

    if a_bytes and b_bytes:
        return not images_changed(a_bytes, b_bytes)

    return False


def _load_image_bytes(sha256: Optional[str]) -> Optional[bytes]:
    """Đọc bytes ảnh từ image_store theo sha256. None nếu không tồn tại hoặc sha256 trống."""
    if not sha256:
        return None
    try:
        from src.services.utils.image_store import load_image
        return load_image(sha256)
    except Exception:
        return None


def _image_payload(
    node: Optional[DocNode],
    include_data: bool = True,
) -> Optional[Dict[str, Any]]:
    """Serialize image node thành payload cho frontend."""
    if node is None:
        return None
    if node.type != "image":
        return None

    content = node.content or {}

    width_emu  = content.get("width_emu")  or 0
    height_emu = content.get("height_emu") or 0

    px_per_emu = 96 / 914400
    width_px   = round(width_emu  * px_per_emu) if width_emu  else content.get("width")
    height_px  = round(height_emu * px_per_emu) if height_emu else content.get("height")

    image_url = content.get("image_url") if include_data else None

    image_block = {
        "name":       content.get("name"),
        "ext":        content.get("ext"),
        "hash":       content.get("hash"),
        "sha256":     content.get("sha256"),
        "width_emu":  width_emu,
        "height_emu": height_emu,
        "width_px":   width_px,
        "height_px":  height_px,
        "image_url":  image_url,
        "mime":       content.get("mime"),
        "rid":        content.get("rid"),
        "floating":   content.get("floating", False),
        "alt_text":   content.get("alt_text", ""),
    }

    return {
        "uid":          getattr(node, "uid",   None),
        "type":         "image",
        "display_type": "image",
        "order":        getattr(node, "order", 0),
        "path":         getattr(node, "path",  ""),
        "image":        image_block,
        "image_url":    image_block["image_url"],
        "text":         content.get("text",    ""),
        "caption":      content.get("caption", ""),
    }


def build_image_change(
    a: Optional[DocNode],
    b: Optional[DocNode],
) -> Dict[str, Any]:
    """Change object cho image, luôn include_data=True để frontend nhận image_url đầy đủ."""
    left_payload  = _image_payload(a, include_data=True)
    right_payload = _image_payload(b, include_data=True)

    if a is not None and b is None:
        return {
            "type":         "image_deleted",
            "display_type": "image",
            "change_kind":  "delete",
            "left":         left_payload,
            "right":        None,
            "left_img":     left_payload,
            "right_img":    None,
        }

    if b is not None and a is None:
        return {
            "type":         "image_added",
            "display_type": "image",
            "change_kind":  "insert",
            "left":         None,
            "right":        right_payload,
            "left_img":     None,
            "right_img":    right_payload,
        }

    return {
        "type":         "image_modified",
        "display_type": "image",
        "change_kind":  "replace",
        "left":         left_payload,
        "right":        right_payload,
        "left_img":     left_payload,
        "right_img":    right_payload,
    }


def build_image_equal(
    a: Optional[DocNode],
    b: Optional[DocNode],
) -> Dict[str, Any]:
    """Change object cho ảnh equal, include_data=False để tiết kiệm bandwidth."""
    left_payload  = _image_payload(a, include_data=False)
    right_payload = _image_payload(b, include_data=False)

    return {
        "type":         "image_equal",
        "display_type": "image",
        "change_kind":  "equal",
        "left":         left_payload,
        "right":        right_payload,
        "left_img":     left_payload,
        "right_img":    right_payload,
    }
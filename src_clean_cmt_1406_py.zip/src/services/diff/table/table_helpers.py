"""
Utility thuần cho table diff — dùng LogicalTable/LogicalCell.

row_sig() và row_content_hash() chỉ dùng anchor cells, không dùng spanning
cells, để tránh physical-row bias khi bảng có rowspan lớn.

Import bởi: table_serialize.py, table_diff.py, table_analyze.py
"""

from __future__ import annotations

import difflib
import hashlib
from typing import Any, Dict, List, Optional, Set, Tuple

from src.services.models.logical_table import LogicalCell, LogicalTable
from src.services.extractor.utils import norm_text as _norm


def get_anchor_rows(tbl: LogicalTable) -> List[int]:
    """List anchor_row unique, sort tăng dần."""
    return tbl.anchor_rows()


def get_cells_in_row(tbl: LogicalTable, anchor_row: int) -> List[LogicalCell]:
    """Master cells trong 1 anchor row, sort theo anchor_col."""
    return tbl.cells_in_row(anchor_row)


def get_all_cells(tbl: LogicalTable) -> List[LogicalCell]:
    """Tất cả master cells, sort theo (anchor_row, anchor_col)."""
    return sorted(tbl.cells, key=lambda c: (c.anchor_row, c.anchor_col))


def cell_key(cell: LogicalCell) -> Tuple[int, int]:
    return (cell.anchor_row, cell.anchor_col)


def cell_norm_text(cell: Optional[LogicalCell]) -> str:
    if not cell:
        return ""
    return _norm(cell.text)


def row_norm_text(tbl: LogicalTable, anchor_row: int) -> str:
    """Text của toàn bộ cell trong 1 anchor row, join bằng ' | '."""
    parts = [_norm(c.text) for c in get_cells_in_row(tbl, anchor_row) if _norm(c.text)]
    return " | ".join(parts)


def _short_text_hash(text: str, n: int = 80) -> str:
    """Hash ngắn của normalized text prefix — dùng cho row_sig để align mềm hơn full content hash."""
    text = _norm(text)
    if not text:
        return ""
    return hashlib.md5(text[:n].encode("utf-8")).hexdigest()[:10]


def row_sig(tbl: LogicalTable, anchor_row: int) -> str:
    """
    Signature mềm cho SequenceMatcher align row.

    Không dùng full content_key() (quá strict — sửa text nhẹ cũng bị đẩy
    vào replace) và không dùng raw text prefix (dễ false equal khi nhiều
    row có đầu câu giống nhau). Mỗi cell encode thành
    "{anchor_col}:{N|T}:img{n}:txt{hash}" để giữ cấu trúc cột, semantic
    nested/image, và short hash của text.
    """
    parts: List[str] = []

    for c in get_cells_in_row(tbl, anchor_row):
        text = _norm(c.text)
        layout_kind = "N" if c.nested_table else "T"
        img_count = len(getattr(c, "images", []) or [])
        text_hash = _short_text_hash(text, 80)

        parts.append(f"{c.anchor_col}:{layout_kind}:img{img_count}:txt{text_hash}")

    parts.sort()
    return "|".join(parts)


def row_content_hash(tbl: LogicalTable, anchor_row: int) -> str:
    """
    Hash ổn định cho match_rows_by_content, dùng text thật của row.
    Chỉ fallback về row position khi row hoàn toàn rỗng.
    """
    all_parts: List[Tuple[int, str]] = []

    for c in get_cells_in_row(tbl, anchor_row):
        text = _norm(c.text)
        if text:
            all_parts.append((c.anchor_col, text))

    all_parts.sort()
    combined = " | ".join(text for _, text in all_parts)

    if not combined:
        combined = f"__empty_row_{anchor_row}__"

    return hashlib.md5(combined.encode("utf-8")).hexdigest()


def detect_structure_change(a: LogicalTable, b: LogicalTable) -> bool:
    """
    True nếu 2 LogicalTable khác structure.

    Ưu tiên resolve_header_map(): mapped_ratio = n_matched / max(n_a, n_b),
    structure changed khi mapped_ratio < 0.4. Header match semantic hơn
    total_cols — bảng có subheader/merged cell dễ lệch total_cols dù vẫn
    map được phần lớn cột.

    Không có header đủ tin cậy → fallback abs(total_cols delta) > 1
    (cho phép lệch 1 col do gridSpan khác nhau giữa 2 file).

    Không dùng total_cols != total_cols trực tiếp — quá strict, classify
    nhầm thành full-table quá nhiều.
    """
    header_result = resolve_header_map(a, b)
    if header_result["has_header"]:
        col_map   = header_result["col_map"]
        n_matched = len(col_map)
        n_a       = n_matched + len(header_result["deleted_cols"])
        n_b       = n_matched + len(header_result["added_cols"])
        denom     = max(n_a, n_b, 1)
        return (n_matched / denom) < 0.4

    return abs(a.total_cols - b.total_cols) > 1


def _detect_header_rows(tbl: LogicalTable) -> List[int]:
    """
    List anchor_rows được coi là header (tối đa 3), dừng khi gặp row đầu
    tiên có numeric content thật (giá tiền, số lượng — không phải STT 1-3 chữ số).
    Luôn trả ít nhất [anchor_rows[0]] nếu bảng không rỗng.
    """
    import re
    anchor_rows = get_anchor_rows(tbl)
    header_rows: List[int] = []

    for r in anchor_rows[:3]:
        cells = get_cells_in_row(tbl, r)
        if not cells:
            break

        texts = [_norm(c.text) for c in cells if _norm(c.text)]
        if not texts:
            break

        has_numeric = any(
            re.search(r"\d{2,}", t) and not re.fullmatch(r"\d{1,3}", t)
            for t in texts
        )
        if has_numeric:
            break

        header_rows.append(r)

    if not header_rows and anchor_rows:
        header_rows = [anchor_rows[0]]

    return header_rows


def resolve_header_map(
    a: LogicalTable,
    b: LogicalTable,
    fuzzy_threshold: float = 0.6,
) -> Dict[str, Any]:
    """
    Align header rows của 2 bảng → map anchor_col_A → anchor_col_B.
    Hỗ trợ multi-row header: combine text theo từng anchor_col.
    """
    a_rows = get_anchor_rows(a)
    b_rows = get_anchor_rows(b)

    if not a_rows or not b_rows:
        return {"col_map": {}, "added_cols": [], "deleted_cols": [], "has_header": False}

    a_header_rows = _detect_header_rows(a)
    b_header_rows = _detect_header_rows(b)

    def _build_col_text_map(tbl: LogicalTable, header_rows: List[int]) -> Dict[int, str]:
        """
        anchor_col → combined text từ các header rows. Cell span nhiều col
        → text gán cho tất cả cols nó phủ. Multi-row header join bằng ' / ',
        dedup giữ thứ tự.
        """
        col_parts: Dict[int, List[str]] = {}
        for r in header_rows:
            for c in get_cells_in_row(tbl, r):
                txt = _norm(c.text)
                if not txt:
                    continue
                for k in range(c.col_span):
                    col = c.anchor_col + k
                    col_parts.setdefault(col, []).append(txt)

        return {
            col: " / ".join(dict.fromkeys(parts))
            for col, parts in col_parts.items()
        }

    a_headers = _build_col_text_map(a, a_header_rows)
    b_headers = _build_col_text_map(b, b_header_rows)

    if not a_headers or not b_headers:
        return {"col_map": {}, "added_cols": [], "deleted_cols": [], "has_header": False}

    matched_a: Set[int] = set()
    matched_b: Set[int] = set()
    candidates: List[Tuple[float, int, int]] = []

    for a_col, a_text in a_headers.items():
        for b_col, b_text in b_headers.items():
            if not a_text and not b_text:
                ratio = 1.0
            elif not a_text or not b_text:
                ratio = 0.0
            else:
                ratio = difflib.SequenceMatcher(a=a_text, b=b_text, autojunk=False).ratio()
                min_len = min(len(a_text), len(b_text))
                # header ngắn (<4 ký tự) dễ match nhầm → cần ratio cao hơn
                effective_threshold = 0.85 if min_len < 4 else fuzzy_threshold
                if ratio < effective_threshold:
                    continue
            candidates.append((-ratio, a_col, b_col))

    candidates.sort()
    col_map: Dict[int, int] = {}
    for _, a_col, b_col in candidates:
        if a_col in matched_a or b_col in matched_b:
            continue
        col_map[a_col] = b_col
        matched_a.add(a_col)
        matched_b.add(b_col)

    return {
        "col_map":      col_map,
        "added_cols":   sorted(b_col for b_col in b_headers if b_col not in matched_b),
        "deleted_cols": sorted(a_col for a_col in a_headers if a_col not in matched_a),
        "has_header":   True,
    }


def match_rows_by_content(
    a: LogicalTable,
    b: LogicalTable,
) -> Dict[str, Any]:
    """
    Match anchor rows giữa 2 bảng theo content hash.

    Trả {"a_states": {anchor_row: "unchanged"|"deleted"},
         "b_states": {anchor_row: "unchanged"|"added"}}.
    """
    a_rows = get_anchor_rows(a)
    b_rows = get_anchor_rows(b)

    a_hashes = [row_content_hash(a, r) for r in a_rows]
    b_hashes = [row_content_hash(b, r) for r in b_rows]

    sm = difflib.SequenceMatcher(a=a_hashes, b=b_hashes, autojunk=False)

    a_states: Dict[int, str] = {}
    b_states: Dict[int, str] = {}

    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "equal":
            for k in range(i2 - i1):
                a_states[a_rows[i1 + k]] = "unchanged"
                b_states[b_rows[j1 + k]] = "unchanged"
        elif tag == "delete":
            for i in range(i1, i2):
                a_states[a_rows[i]] = "deleted"
        elif tag == "insert":
            for j in range(j1, j2):
                b_states[b_rows[j]] = "added"
        elif tag == "replace":
            for i in range(i1, i2):
                a_states[a_rows[i]] = "deleted"
            for j in range(j1, j2):
                b_states[b_rows[j]] = "added"

    return {"a_states": a_states, "b_states": b_states}
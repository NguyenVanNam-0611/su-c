"""
extractor/paragraph.py
~~~~~~~~~~~~~~~~~~~~~~
Extract paragraph và heading từ docx thành DocNode.

Chỉ chịu trách nhiệm:
    - Extract text normalized + text_display
    - Detect heading + heading level
    - Extract numbering/list cơ bản + tính label thực tế ("1.", "a)", "•" ...)
    - Extract inline image
    - Extract shape và emit shape thành sibling node

KHÔNG extract: font name, font size, color, bold/italic/underline,
paragraph spacing/alignment, layout formatting.
"""

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional

from docx.text.paragraph import Paragraph
from docx.oxml.ns import qn as _qn
from src.services.models.docnode import DocNode
from src.services.extractor.image import extract_inline_images
from src.services.extractor.shape.shape import extract_shapes_from_paragraph
from src.services.extractor.utils import OrderRef, norm_for_signature, raw_text, next_order
from src.services.extractor.numbering import (
    resolve_numbering,
    compute_numbering_label,
    CounterState,
)


_HEADING_RE = re.compile(r"heading\s*(\d+)", re.IGNORECASE)


def extract_page_number(
    par: Paragraph,
    current_page: int,
) -> tuple[int, int]:
    """
    Trả về (paragraph_page, next_page): page của paragraph hiện tại, và
    page sẽ áp dụng cho paragraph kế tiếp (sau khi tính các page break
    nằm trong paragraph này).
    """
    paragraph_page = current_page
    next_page = current_page

    pPr = par._p.pPr
    if pPr is not None:
        pbB = pPr.find(_qn("w:pageBreakBefore"))

        if pbB is not None:
            val = pbB.get(_qn("w:val"), "true")
            if val not in ("false", "0"):
                paragraph_page += 1
                next_page += 1

    for elem in par._p.iter():
        if elem.tag == _qn("w:lastRenderedPageBreak"):
            next_page += 1
        elif elem.tag == _qn("w:br"):
            if elem.get(_qn("w:type")) == "page":
                next_page += 1

    return paragraph_page, next_page


def heading_level(style_name: str) -> int:
    if not style_name:
        return 0
    m = _HEADING_RE.search(style_name.strip())
    return int(m.group(1)) if m else 0


def is_heading(par: Paragraph) -> bool:
    style_name = (par.style.name if par.style else "") or ""
    return style_name.strip().lower().startswith("heading")


def extract_numbering(
    par: Paragraph,
    numbering_map: Optional[Dict[str, Any]] = None,
    counter_state: Optional[CounterState] = None,
) -> Optional[Dict[str, Any]]:
    """
    Extract numbering/list info của paragraph, dạng:
        {"num_id": "1", "level": 0, "num_fmt": "decimal" | "lowerLetter" | ...,
         "lvl_text": "%1." | "", "label": "1." | "a)" | "•" | ...}

    label (text hiển thị thực tế) chỉ được tính khi counter_state được truyền
    vào, và counter_state phải được khởi tạo 1 lần ở document level rồi
    truyền qua toàn bộ paragraph theo đúng thứ tự document — nếu không
    thứ tự đếm "1., 2., 3." sẽ sai.
    """
    try:
        pPr = par._p.pPr
        if pPr is None:
            return None

        numPr = pPr.numPr
        if numPr is None:
            return None

        num_id = numPr.numId.val if numPr.numId is not None else None
        level  = numPr.ilvl.val  if numPr.ilvl  is not None else None

        if num_id is None and level is None:
            return None

        resolved: Dict[str, Any] = {}
        label = ""

        if numbering_map:
            num_id_str = str(num_id) if num_id is not None else None
            level_int  = int(level)  if level  is not None else 0

            resolved = resolve_numbering(
                numbering_map=numbering_map,
                num_id=num_id_str,
                level=level_int,
            )

            if counter_state is not None:
                label = compute_numbering_label(
                    numbering_map=numbering_map,
                    counter_state=counter_state,
                    num_id=num_id_str,
                    level=level_int,
                )

        return {
            "num_id":   str(num_id) if num_id is not None else None,
            "level":    int(level)  if level  is not None else 0,
            "num_fmt":  resolved.get("num_fmt"),
            "lvl_text": resolved.get("lvl_text"),
            "label":    label,
        }

    except Exception:
        return None


def extract_runs(par: Paragraph) -> List[Dict[str, Any]]:
    """Chỉ extract text của run — không lấy bold/italic/underline/font/color
    vì project không so sánh style."""
    runs: List[Dict[str, Any]] = []

    for idx, run in enumerate(par.runs):
        text = run.text or ""
        if not text:
            continue
        runs.append({"index": idx, "text": text})

    return runs


def build_paragraph_content(
    par: Paragraph,
    imgs: List[DocNode],
    shapes: List[DocNode],
    in_toc: bool,
    numbering_map: Optional[Dict[str, Any]] = None,
    counter_state: Optional[CounterState] = None,
    page: int = 1,
    para_idx: int = 0,
) -> Dict[str, Any]:
    """
    Contract:
        text:         text đã normalize để diff/signature
        text_display: text giữ layout nhẹ để render UI
        numbering:    list info + label thực tế để hiển thị
    """
    raw     = par.text or ""
    text    = norm_for_signature(raw)
    display = raw_text(raw)

    style_name = (par.style.name if par.style else "") or ""
    heading    = is_heading(par)
    level      = heading_level(style_name) if heading else 0

    return {
        "text":         text,
        "text_display": display,

        "is_heading":    heading,
        "heading_level": level,
        "level":         level,
        "page":          page,
        "para_idx":      para_idx,
        "numbering": extract_numbering(
            par,
            numbering_map=numbering_map,
            counter_state=counter_state,
        ),

        "run_count": len(par.runs),
        "runs":      extract_runs(par),

        "image_count": len(imgs),
        "shape_count": len(shapes),
        "in_toc":      in_toc,
    }


def _make_text_node(
    *,
    node_type: str,
    uid: str,
    parent_uid: Optional[str],
    order_ref: OrderRef,
    content: Dict[str, Any],
) -> DocNode:
    return DocNode(
        type=node_type,
        uid=uid,
        parent_uid=parent_uid,
        order=next_order(order_ref),
        path=uid.replace(".", "/"),
        content=content,
    )


def _attach_images(
    node: DocNode,
    imgs: List[DocNode],
    order_ref: OrderRef,
    page: int = 1,
) -> None:
    for img in imgs:
        img.order = next_order(order_ref)
        if "page" not in (img.content or {}):
            img.content["page"] = page
        node.add_child(img)


def _emit_shapes(
    shapes: List[DocNode],
    order_ref: OrderRef,
    page: int = 1,
) -> List[DocNode]:
    result: List[DocNode] = []
    for shp in shapes:
        shp.order = next_order(order_ref)
        if "page" not in (shp.content or {}):
            shp.content["page"] = page
        result.append(shp)
    return result


def _extract_shift_enter_nodes(
    par: Paragraph,
    uid: str,
    parent_uid: Optional[str],
    order_ref: OrderRef,
    in_toc: bool,
    numbering_map: Optional[Dict[str, Any]],
    counter_state: Optional[CounterState],
    parts: List[str],
    page: int = 1,
) -> List[DocNode]:
    """
    Xử lý paragraph có Shift+Enter (vertical tab \\x0b): tách thành nhiều
    paragraph/heading node để diff text dễ hơn.

    Numbering chỉ tính 1 lần cho cả paragraph gốc (không đếm lại mỗi part) —
    counter chỉ tăng đúng 1 lần dù paragraph bị tách thành nhiều node.

    Trade-off: không map run/image vào từng part; shape được emit ở caller.
    """
    style_name = (par.style.name if par.style else "") or ""
    heading    = is_heading(par)
    level      = heading_level(style_name) if heading else 0

    numbering = extract_numbering(
        par,
        numbering_map=numbering_map,
        counter_state=counter_state,
    )

    nodes: List[DocNode] = []

    for k, raw_part in enumerate(parts):
        raw_part = raw_part.strip()
        if not raw_part:
            continue

        part_text    = norm_for_signature(raw_part)
        part_display = raw_text(raw_part)
        part_uid     = f"{uid}.s{k}"

        node_type  = "heading" if (k == 0 and heading) else "paragraph"
        node_level = level if node_type == "heading" else 0

        content = {
            "text":         part_text,
            "text_display": part_display,

            "is_heading":    node_type == "heading",
            "heading_level": node_level,
            "level":         node_level,
            "page":          page,

            "numbering": numbering,

            "run_count": 0,
            "runs":      [],

            "image_count": 0,
            "shape_count": 0,
            "in_toc":      in_toc,
        }

        nodes.append(
            _make_text_node(
                node_type=node_type,
                uid=part_uid,
                parent_uid=parent_uid,
                order_ref=order_ref,
                content=content,
            )
        )

    return nodes


def extract_paragraph_nodes(
    par: Paragraph,
    uid: str,
    parent_uid: Optional[str],
    order_ref: OrderRef,
    in_toc: bool = False,
    numbering_map: Optional[Dict[str, Any]] = None,
    counter_state: Optional[CounterState] = None,
    page: int = 1,
    para_idx: int = 0,
) -> List[DocNode]:
    """
    Extract 1 docx Paragraph thành list DocNode. Có thể trả [], [paragraph],
    [heading], [paragraph/heading, shape...], hoặc nhiều paragraph nếu có
    Shift+Enter.

    counter_state phải được truyền từ document level để numbering label
    ("1.", "2.", "a)"...) được tính đúng thứ tự.
    """
    raw = par.text or ""

    if "\x0b" in raw:
        nodes = _extract_shift_enter_nodes(
            par=par,
            uid=uid,
            parent_uid=parent_uid,
            order_ref=order_ref,
            in_toc=in_toc,
            numbering_map=numbering_map,
            counter_state=counter_state,
            parts=raw.split("\x0b"),
            page=page,
        )

        # Vẫn emit shape để không mất floating shape của paragraph gốc
        shapes = extract_shapes_from_paragraph(
            par,
            uid_prefix=f"{uid}.shp",
            parent_uid=parent_uid,
            order_ref=order_ref,
        )
        nodes.extend(_emit_shapes(shapes, order_ref, page=page))
        return nodes

    imgs = extract_inline_images(
        par,
        uid_prefix=f"{uid}.img",
        parent_uid=uid,
        order_ref=order_ref,
    )

    shapes = extract_shapes_from_paragraph(
        par,
        uid_prefix=f"{uid}.shp",
        parent_uid=parent_uid,
        order_ref=order_ref,
    )

    content = build_paragraph_content(
        par=par,
        imgs=imgs,
        shapes=shapes,
        in_toc=in_toc,
        numbering_map=numbering_map,
        counter_state=counter_state,
        page=page,
        para_idx=para_idx,
    )

    text      = content["text"]
    node_type = "heading" if content["is_heading"] else "paragraph"

    nodes: List[DocNode] = []

    if text or imgs:
        node = _make_text_node(
            node_type=node_type,
            uid=uid,
            parent_uid=parent_uid,
            order_ref=order_ref,
            content=content,
        )
        _attach_images(node, imgs, order_ref, page=page)
        nodes.append(node)

    # Shape emit độc lập, kể cả khi paragraph rỗng (không tạo text node)
    nodes.extend(_emit_shapes(shapes, order_ref, page=page))

    return nodes
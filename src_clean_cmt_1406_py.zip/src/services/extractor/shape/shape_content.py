"""
extractor/shape_content.py
~~~~~~~~~~~~~~~~~~~~~~~~~~
Collect nội dung có nghĩa từ DocNode(type="shape") — text và image.

Đây là file TRUNG TÂM duy nhất định nghĩa "shape gồm những gì".
Tất cả nơi cần biết nội dung shape đều import từ đây:
    - signature.py      → _sig_shape dùng collect_shape_parts
    - sequence_align.py → _content_sig, _shape_text dùng collect_shape_parts
    - shape_diff.py     → collect_diffable_nodes dùng để diff

Nguyên tắc:
    - Text: lấy từ paragraph có text thực sự (sau norm_text)
    - Image: lấy sha256 — stable, không phụ thuộc tên file hay vị trí
    - Thứ tự: giữ đúng thứ tự xuất hiện trong shape (paragraph xen kẽ image)
    - Đệ quy: shape lồng nhau, table trong shape → cell → paragraph/image

KHÔNG xử lý: format (bold, font size, alignment).
"""

from __future__ import annotations

from typing import List

from src.services.models.docnode import DocNode
from src.services.extractor.utils import norm_text as _norm_text


def _collect_from_cell(cell: DocNode, out: List[str]) -> None:
    for c in (cell.children or []):
        if c.type == "paragraph":
            _collect_from_paragraph(c, out)
        elif c.type == "table":
            _collect_from_table(c, out)


def _collect_from_paragraph(par: DocNode, out: List[str]) -> None:
    txt = _norm_text(par.content.get("text", ""))
    if txt:
        out.append(txt)

    for gc in (par.children or []):
        if gc.type == "image":
            sha = gc.content.get("sha256", "") or ""
            if sha:
                out.append(f"img:{sha[:16]}")


def _collect_from_table(tbl: DocNode, out: List[str]) -> None:
    for row in (tbl.children or []):
        if row.type != "row":
            continue
        for cell in (row.children or []):
            if cell.type == "cell":
                _collect_from_cell(cell, out)


def collect_shape_parts(node: DocNode) -> List[str]:
    """
    Collect tất cả nội dung có nghĩa từ shape node thành list string, mỗi phần
    tử là text paragraph (norm_text) hoặc "img:{sha256[:16]}", giữ đúng thứ tự
    xuất hiện. Đệ quy vào shape lồng nhau, table, cell.

    Dùng để tính signature, so sánh nội dung (SequenceMatcher), và kiểm tra
    shape rỗng (len == 0).
    """
    out: List[str] = []

    for child in (node.children or []):
        if child.type == "paragraph":
            _collect_from_paragraph(child, out)
        elif child.type == "image":
            sha = child.content.get("sha256", "") or ""
            if sha:
                out.append(f"img:{sha[:16]}")
        elif child.type == "shape":
            out.extend(collect_shape_parts(child))
        elif child.type == "table":
            _collect_from_table(child, out)

    return out


def collect_diffable_nodes(node: DocNode) -> List[DocNode]:
    """
    Collect tất cả node có thể diff từ shape theo đúng thứ tự xuất hiện.

    Paragraph có text hoặc image con được emit như MỘT đơn vị duy nhất —
    image con KHÔNG emit riêng, vì shape_diff._handle_replace_pair và
    _diff_image_children tự xử lý image con bên trong paragraph đó.
    Double-emit sẽ khiến image bị diff hai lần.

    Paragraph rỗng hoàn toàn (không text, không image con) bị bỏ qua.
    Image direct child của shape (không có paragraph bọc) được emit riêng.
    """
    result: List[DocNode] = []

    for child in (node.children or []):
        if child.type == "paragraph":
            has_text   = bool(_norm_text(child.content.get("text", "")))
            has_images = any(gc.type == "image" for gc in (child.children or []))

            if has_text or has_images:
                result.append(child)

        elif child.type == "image":
            result.append(child)

        elif child.type == "shape":
            result.extend(collect_diffable_nodes(child))

        elif child.type == "table":
            result.extend(_collect_diffable_from_table(child))

    return result


def _collect_diffable_from_table(tbl: DocNode) -> List[DocNode]:
    result: List[DocNode] = []
    for row in (tbl.children or []):
        if row.type != "row":
            continue
        for cell in (row.children or []):
            if cell.type == "cell":
                result.extend(_collect_diffable_from_cell(cell))
    return result


def _collect_diffable_from_cell(cell: DocNode) -> List[DocNode]:
    """Áp dụng cùng quy tắc emit như collect_diffable_nodes (xem docstring đó)."""
    result: List[DocNode] = []
    for c in (cell.children or []):
        if c.type == "paragraph":
            has_text   = bool(_norm_text(c.content.get("text", "")))
            has_images = any(gc.type == "image" for gc in (c.children or []))

            if has_text or has_images:
                result.append(c)

        elif c.type == "image":
            result.append(c)

        elif c.type == "table":
            result.extend(_collect_diffable_from_table(c))
    return result
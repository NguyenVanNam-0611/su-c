"""
extractor/utils.py
~~~~~~~~~~~~~~~~~~
Các helper thuần tuý dùng chung cho extractor và diff.
"""

from __future__ import annotations

import re
import unicodedata
from typing import Dict, List, Optional


OrderRef = Dict[str, int]


# Các biến thể Unicode của space cần collapse về ASCII space.
# \u2028/\u2029 (line/paragraph separator) xử lý riêng bên dưới
# vì một số caller cần giữ chúng làm soft line break có ngữ nghĩa.
_SPACE_VARIANTS = (
    "\u00a0"  # non-breaking space
    "\u2002"  # en space
    "\u2003"  # em space
    "\u2004"
    "\u2005"
    "\u2006"
    "\u2007"
    "\u2008"
    "\u2009"
    "\u200a"
    "\u202f"
    "\u3000"
)

# Ký tự invisible không mang ngữ nghĩa, xoá hoàn toàn.
# \x0b (Shift+Enter), \u2028, \u2029 cố ý loại khỏi danh sách này —
# chúng biểu thị soft line break và được dispatch riêng tuỳ caller.
_DROP_CHARS = (
    "\u200b"  # zero-width space
    "\u200c"  # zero-width non-joiner
    "\u200d"  # zero-width joiner
    "\u2060"  # word joiner
    "\ufeff"  # BOM
    "\u00ad"  # soft hyphen
    "\x0c"    # form feed
    "\x1c"
    "\x1d"
    "\x1e"
)

_TO_SPACE_TABLE = str.maketrans(_SPACE_VARIANTS, " " * len(_SPACE_VARIANTS))
_DROP_TABLE = str.maketrans("", "", _DROP_CHARS)

_SHIFT_ENTER = "\x0b"


def _normalize_base(
    s: str,
    *,
    preserve_break: bool = False,
) -> str:
    """
    Normalize Unicode cốt lõi, dùng chung cho tất cả hàm norm_* bên ngoài.

    preserve_break=True chèn token <BR> thay cho Shift+Enter / \u2028 / \u2029
    để "A\x0bB" khác với "A B" khi tạo paragraph signature.
    """
    if not s:
        return ""

    s = unicodedata.normalize("NFC", s)

    br = " <BR> " if preserve_break else " "

    s = s.replace(_SHIFT_ENTER, br)
    s = s.replace("\u2028", br)
    s = s.replace("\u2029", br)

    s = s.translate(_DROP_TABLE)
    s = s.translate(_TO_SPACE_TABLE)

    if preserve_break:
        s = (
            s.replace("\r\n", br)
             .replace("\r", br)
             .replace("\n", br)
             .replace("\t", " ")
        )
    else:
        s = (
            s.replace("\r\n", " ")
             .replace("\r", " ")
             .replace("\n", " ")
             .replace("\t", " ")
        )

    return s


def norm_text(s: str) -> str:
    """Normalize cơ bản cho content paragraph/heading và text search đơn giản."""
    s = _normalize_base(s)
    return " ".join(s.split()).strip()


def norm_for_signature(s: str) -> str:
    """
    Normalize ổn định để tạo paragraph signature.

    Giữ soft line break dưới dạng token <BR> để "A\\x0bB" và "A B"
    cho ra signature khác nhau, tránh bỏ sót thay đổi.
    Chuẩn hoá khoảng trắng quanh dấu phẩy/chấm phẩy để diff không
    bị nhiễu bởi thay đổi cosmetic.
    """
    s = _normalize_base(s, preserve_break=True)
    s = " ".join(s.split()).strip()

    # Chuẩn hoá spacing dấu phẩy/chấm phẩy: "A ,B", "A,B", "A, B" → "A, B"
    s = re.sub(r"\s*([,;])\s*(?=\S)", r"\1 ", s)
    s = re.sub(r"\s+([,;])$", r"\1", s)

    # Bỏ space thừa trong ngoặc đơn
    s = re.sub(r"\(\s+", "(", s)
    s = re.sub(r"\s+\)", ")", s)

    return " ".join(s.split()).strip()


def norm_for_diff(s: str) -> str:
    """
    Normalize để tokenize trong word-level diff.

    Tách dấu phẩy/chấm phẩy thành token riêng để thay đổi punctuation
    được hiện ra như diff operation độc lập, không bị gộp vào từ kề.
    """
    s = norm_for_signature(s)
    s = re.sub(r"\s*([,;])\s*", r" \1 ", s)
    return " ".join(s.split()).strip()


def norm_for_align(s: str) -> str:
    """
    Normalize lỏng để align multiline/table text.

    Collapse dấu phẩy/chấm phẩy thành space để chênh lệch nhỏ về
    list formatting không chặn alignment. Không dùng cho primary
    paragraph signature — sẽ bỏ sót thay đổi punctuation.
    """
    s = norm_for_signature(s)
    s = re.sub(r"[,;]\s*", " ", s)
    return " ".join(s.split()).strip()


def _detokenize(tokens: List[str]) -> str:
    """Ghép token list về chuỗi tự nhiên để render diff span."""
    result = ""

    for i, tok in enumerate(tokens):
        if tok in (",", ";"):
            result = result.rstrip() + tok + " "
        elif i == 0:
            result += tok
        else:
            result += " " + tok

    return result.strip()


def raw_text(s: str) -> str:
    """
    Normalize nhẹ, giữ nguyên newline để UI render đúng.

    Chuyển Shift+Enter (\x0b) và line separator thành \\n thật
    thay vì collapse thành space như các hàm norm_* khác.
    """
    if not s:
        return ""

    s = unicodedata.normalize("NFC", s)

    s = s.replace(_SHIFT_ENTER, "\n")
    s = s.replace("\u2028", "\n").replace("\u2029", "\n")
    s = s.replace("\r\n", "\n").replace("\r", "\n")

    s = s.translate(_DROP_TABLE)
    s = s.translate(_TO_SPACE_TABLE)

    return s.strip()


def next_order(order_ref: Optional[OrderRef]) -> int:
    if order_ref is None:
        return 0

    order_ref["value"] += 1
    return order_ref["value"]


def safe_pt(value) -> Optional[float]:
    try:
        return value.pt if value is not None else None
    except Exception:
        return None
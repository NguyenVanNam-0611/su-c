"""
page/page_injector.py

Inject page number thật (từ COM) vào DocNode tree.

Chiến lược:
- heading/paragraph : dùng para_idx / content["text"]
- table             : dùng table_idx
- shape             : dùng shape_id
- image             : lấy page từ parent qua pass-2 propagate

Nếu COM không trả page cho uid nào đó → giữ nguyên page cũ.
"""
from __future__ import annotations

import logging
from typing import Dict, List, Tuple

from src.services.models.docnode import DocNode

logger = logging.getLogger(__name__)


def collect_uid_text_pairs(root: DocNode) -> List[Tuple[str, str]]:
    pairs: List[Tuple[str, str]] = []

    def _walk(node: DocNode) -> None:
        t = node.type

        if t in ("heading", "paragraph"):
            text = (node.content.get("text") or "").strip()
            if text:
                pairs.append((node.uid, text[:400]))

        elif t == "table":
            key = _first_cell_text(node)
            if key:
                pairs.append((node.uid, key))

        if t != "table":
            for child in node.children or []:
                _walk(child)

    for child in root.children or []:
        _walk(child)

    return pairs


def collect_uid_index_pairs(root: DocNode) -> List[Tuple[str, str, object]]:
    """
    Trả list (uid, obj_type, idx_or_id) để COM truy cập trực tiếp bằng index.

    obj_type = "para"  → idx: int, dùng doc.Paragraphs(idx)
    obj_type = "table" → idx: int, dùng doc.Tables(idx)
    obj_type = "shape" → idx: str shape_id, dùng doc.Shapes map
    image bỏ qua — lấy page từ parent qua pass-2 propagate.
    """
    pairs = []

    def _walk(node: DocNode) -> None:
        t = node.type

        if t in ("heading", "paragraph"):
            idx = node.content.get("para_idx", 0)
            if idx:
                pairs.append((node.uid, "para", idx))

        elif t == "table":
            idx = node.content.get("table_idx", 0)
            if idx:
                pairs.append((node.uid, "table", idx))

        elif t == "shape":
            shape_id = (node.content or {}).get("shape_id", "")
            if shape_id:
                pairs.append((node.uid, "shape", str(shape_id)))

        if t != "table":
            for child in node.children or []:
                _walk(child)

    for child in root.children or []:
        _walk(child)

    return pairs


def inject_pages(root: DocNode, page_map: Dict[str, int]) -> None:
    """Ghi page_map vào node.content["page"] cho toàn bộ tree. In-place."""
    if not page_map:
        return

    def _walk(node: DocNode) -> None:
        if node.uid in page_map:
            node.content["page"] = page_map[node.uid]
        for child in node.children or []:
            _walk(child)

    _walk(root)

    # Pass-2: image không có COM index → inherit page từ parent paragraph/shape
    def _propagate(node: DocNode) -> None:
        if node.type in ("shape", "paragraph", "heading"):
            parent_page = node.content.get("page")
            if parent_page:
                for child in node.children or []:
                    if child.type == "image" and not child.content.get("page"):
                        child.content["page"] = parent_page
        for child in node.children or []:
            _propagate(child)

    _propagate(root)
    logger.info(f"[INJECTOR] Đã inject page cho {len(page_map)} nodes.")


def _first_cell_text(table_node: DocNode) -> str:
    lt = getattr(table_node, "logical_table", None)

    if lt is not None:
        for cell in lt.cells:
            t = (cell.text or "").strip()
            if t:
                return t[:100]
        return ""

    for row in table_node.children or []:
        if row.type != "row":
            continue
        for cell in row.children or []:
            if cell.type != "cell":
                continue
            text = (cell.content.get("text") or "").strip()
            if text:
                return text[:400]

    return ""
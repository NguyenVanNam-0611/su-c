"""
page/com_pager.py
~~~~~~~~~~~~~~~~~
Dùng Word COM để lấy page thật cho từng block uid.

Input : docx_path + danh sách (uid, search_text)
Output: dict[uid → page_number]

Chạy trên Windows, cần Word cài sẵn.
Fallback: trả {} nếu COM không khả dụng.
"""
from __future__ import annotations

import logging
import os
import sys
from typing import Dict, List, Tuple

logger = logging.getLogger(__name__)

_WD_COLLAPSE_START = 1
_WD_ACTIVE_END_PAGE_NUMBER = 3


def get_pages_via_com(
    docx_path: str,
    uid_text_pairs: List[Tuple[str, str]],
) -> Dict[str, int]:
    if sys.platform != "win32":
        logger.warning("[COM] Không phải Windows — bỏ qua COM pager.")
        return {}

    if not uid_text_pairs:
        return {}

    try:
        import pythoncom
        import win32com.client
    except ImportError:
        logger.warning("[COM] pywin32 chưa cài — bỏ qua COM pager.")
        return {}

    abs_path = os.path.normpath(os.path.abspath(str(docx_path)))

    if not os.path.exists(abs_path):
        logger.error(f"[COM] File không tồn tại: {abs_path}")
        return {}

    word = None
    doc = None
    result: Dict[str, int] = {}

    com_initialized = False

    try:
        pythoncom.CoInitializeEx(
            pythoncom.COINIT_APARTMENTTHREADED
        )
        com_initialized = True

        word = win32com.client.DispatchEx("Word.Application")
        word.Visible = False
        word.DisplayAlerts = 0

        doc = word.Documents.Open(
            abs_path,
            ReadOnly=True,
            AddToRecentFiles=False,
            ConfirmConversions=False,
        )

        # ép Word paginate lại để page number ổn hơn
        try:
            doc.Repaginate()
        except Exception:
            pass

        for uid, search_text in uid_text_pairs:
            text = (search_text or "").strip()
            if not text:
                continue

            try:
                page = _find_page(doc, text[:100])
                if page:
                    result[uid] = page
            except Exception as e:
                logger.debug(f"[COM] uid={uid} find failed: {e}")
                continue

    except Exception as e:
        logger.error(f"[COM] Word COM error: {e}")

    finally:
        try:
            if doc is not None:
                doc.Close(False)
        except Exception:
            pass

        try:
            if word is not None:
                word.Quit()
        except Exception:
            pass

        if com_initialized:
            try:
                pythoncom.CoUninitialize()
            except Exception:
                pass

    logger.info(
        f"[COM] Lấy page cho {len(result)}/{len(uid_text_pairs)} blocks."
    )
    return result


def _find_page(doc, text: str) -> int | None:
    """
    Tìm text trong doc, lấy page của vị trí đầu tiên tìm thấy.
    """
    if not text:
        return None

    rng = doc.Content
    rng.Find.ClearFormatting()

    found = rng.Find.Execute(
        FindText=text,
        MatchCase=False,
        MatchWholeWord=False,
        Forward=True,
    )

    if not found:
        return None

    rng.Collapse(_WD_COLLAPSE_START)

    return int(
        rng.Information(_WD_ACTIVE_END_PAGE_NUMBER)
    )
def get_pages_via_com_index(
    docx_path: str,
    uid_index_pairs: List[Tuple[str, str, int]],
) -> Dict[str, int]:
    """
    Lấy page number bằng COM index trực tiếp.

    uid_index_pairs: List[(uid, obj_type, idx)]
        obj_type = "para"  → doc.Paragraphs(idx).Range
        obj_type = "table" → doc.Tables(idx).Range
        idx là 1-based (đã set đúng từ extractor)

    Chính xác hơn get_pages_via_com vì không dùng Find text
    — không bị nhầm khi có duplicate text trong document.
    """
    if sys.platform != "win32":
        logger.warning("[COM] Không phải Windows — bỏ qua COM pager.")
        return {}

    if not uid_index_pairs:
        return {}

    try:
        import pythoncom
        import win32com.client
    except ImportError:
        logger.warning("[COM] pywin32 chưa cài — bỏ qua COM pager.")
        return {}

    abs_path = os.path.normpath(os.path.abspath(str(docx_path)))

    if not os.path.exists(abs_path):
        logger.error(f"[COM] File không tồn tại: {abs_path}")
        return {}

    word = None
    doc  = None
    result: Dict[str, int] = {}
    com_initialized = False

    try:
        pythoncom.CoInitializeEx(pythoncom.COINIT_APARTMENTTHREADED)
        com_initialized = True

        word = win32com.client.DispatchEx("Word.Application")
        word.Visible = False
        word.DisplayAlerts = 0

        doc = word.Documents.Open(
            abs_path,
            ReadOnly=True,
            AddToRecentFiles=False,
            ConfirmConversions=False,
        )

        try:
            doc.Repaginate()
        except Exception:
            pass

        para_count  = doc.Paragraphs.Count
        table_count = doc.Tables.Count

        for uid, obj_type, idx in uid_index_pairs:
            try:
                if obj_type == "para":
                    if idx < 1 or idx > para_count:
                        logger.debug(f"[COM] para idx={idx} out of range (max={para_count})")
                        continue
                    rng = doc.Paragraphs(idx).Range

                elif obj_type == "table":
                    if idx < 1 or idx > table_count:
                        logger.debug(f"[COM] table idx={idx} out of range (max={table_count})")
                        continue
                    rng = doc.Tables(idx).Range

                else:
                    continue

                page = int(rng.Information(_WD_ACTIVE_END_PAGE_NUMBER))
                result[uid] = page

            except Exception as e:
                logger.debug(f"[COM] uid={uid} obj_type={obj_type} idx={idx} failed: {e}")
                continue

    except Exception as e:
        logger.error(f"[COM] Word COM error: {e}")

    finally:
        try:
            if doc is not None:
                doc.Close(False)
        except Exception:
            pass

        try:
            if word is not None:
                word.Quit()
        except Exception:
            pass

        if com_initialized:
            try:
                pythoncom.CoUninitialize()
            except Exception:
                pass

    logger.info(
        f"[COM] Index-based: lấy page cho {len(result)}/{len(uid_index_pairs)} blocks."
    )
    return result
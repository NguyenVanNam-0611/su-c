// components/DiffSection.jsx
import { MetaRow, WordDiff, EmptyHint, ImgBox } from './WordDiff';
import { TextChangeRow } from './renderers/TextChange';
import { ImageChange } from './renderers/ImageChange';
import { TableChange } from './table/TableChange';


// ─────────────────────────────────────────────────────────────
// SHAPE helpers
// ─────────────────────────────────────────────────────────────

function ShapeImgLine({
    url,
    lineClass,
    status = 'equal'
}) {
    if (!url) return null;

    const labelMap = {
        replace: 'Ảnh thay đổi',
        insert: 'Ảnh thêm mới',
        delete: 'Ảnh đã xóa',
        equal: ''
    };

    return (
        <div
            className={`shape-line ${lineClass}`}
            style={{ padding: '4px 0' }}
        >
            <div className={`shape-img-box ${status}`}>
                {status !== 'equal' && (
                    <div className="shape-img-badge">
                        {labelMap[status]}
                    </div>
                )}

                <ImgBox
                    url={url}
                    style={{ maxWidth: '100%' }}
                />
            </div>
        </div>
    );
}

// ─────────────────────────────────────────────────────────────
// SHAPE  (shape_*)
// ─────────────────────────────────────────────────────────────
function getShapeWordDiff(change) {
    return (change.shape_changes || []).find(
        sc => sc.type === 'paragraph_modified' && sc.word_diff
    )?.word_diff || null;
}

function ShapeTextChangesView({ change, side }) {
    const items = (change.shape_changes || [])
        .filter(sc => (sc.type || '').startsWith('paragraph_'));

    if (!items.length) return null;

    return (
        <div className="shape-lines">
            {items.map((sc, i) => {
                const kind = sc.change_kind || 'equal';

                const node = side === 'left'
                    ? (sc.original || sc.left_context)
                    : (sc.modified || sc.right_context);

                if (!node) {
                    return (
                        <div key={i} className="shape-line line-empty">
                            <EmptyHint style={{ padding: 8 }}>
                                {side === 'left' ? '(chưa tồn tại)' : '(đã xóa)'}
                            </EmptyHint>
                        </div>
                    );
                }

                let lineClass = 'line-equal';
                if (kind === 'insert') lineClass = 'line-ins';
                else if (kind === 'delete') lineClass = 'line-del';
                else if (kind === 'replace') lineClass = 'line-modified';

                const text =
                    node.content?.text_display
                    || node.content?.text
                    || '';

                return (
                    <div key={i} className={`shape-line ${lineClass}`}>
                        {sc.word_diff ? (
                            <WordDiff wd={sc.word_diff} side={side} />
                        ) : (
                            <div>{text}</div>
                        )}
                    </div>
                );
            })}
        </div>
    );
}

function ShapeFullView({
    shape,
    side,
    wordDiff,
    lineClass = 'line-equal',
    change
}) {
    const lines = (shape?.shape_text_lines || [])
        .filter(l => !l.startsWith('['));

    const imgs = shape?.shape_images || [];

    function getImgStatus(img) {
        const hash = img?.sha256;
        if (!hash) return 'equal';

        const imgChanges = change?.shape_changes || [];

        for (const sc of imgChanges) {
            if (sc.type !== 'image_modified') continue;

            const leftHash =
                sc.left?.image?.sha256
                || sc.left_img?.image?.sha256;

            const rightHash =
                sc.right?.image?.sha256
                || sc.right_img?.image?.sha256;

            if (hash === leftHash || hash === rightHash) {
                return sc.change_kind || 'replace';
            }
        }

        return 'equal';
    }

    if (!lines.length && !imgs.length) {
        return (
            <EmptyHint style={{ padding: 8 }}>
                (shape trống)
            </EmptyHint>
        );
    }

    return (
        <div className="shape-lines">
            {lines.length > 0 && (
                <div className={`shape-line ${lineClass}`}>
                    {wordDiff ? (
                        <WordDiff wd={wordDiff} side={side} />
                    ) : (
                        lines.map((l, i) => (
                            <div key={i}>{l}</div>
                        ))
                    )}
                </div>
            )}

            {imgs.map((img, i) => (
                <ShapeImgLine
                    key={img.sha256 || img.image_url || i}
                    url={img.image_url}
                    lineClass={lineClass}
                    status={getImgStatus(img)}
                />
            ))}
        </div>
    );
}

function ShapeChangeRow({ change }) {
    const kind = change.change_kind || 'replace';
    const wordDiff = getShapeWordDiff(change);

    if (kind === 'insert') {
        return (
            <div className={`change-row kind-${kind}`}>
                <div className="change-cell left">
                    <MetaRow change={change} side="left"/>
                    <EmptyHint style={{ padding: 8 }}>
                        (chưa tồn tại)
                    </EmptyHint>
                </div>

                <div className="change-cell right">
                    <MetaRow change={change} side="right" />
                    <ShapeFullView
                        shape={change.right}
                        side="right"
                        wordDiff={wordDiff}
                        lineClass="line-ins"
                        change={change}
                    />
                </div>
            </div>
        );
    }

    if (kind === 'delete') {
        return (
            <div className={`change-row kind-${kind}`}>
                <div className="change-cell left">
                    <MetaRow change={change} side="left"/>
                    <ShapeFullView
                        shape={change.left}
                        side="left"
                        wordDiff={wordDiff}
                        lineClass="line-del"
                        change={change}
                    />
                </div>

                <div className="change-cell right">
                    <MetaRow change={change} side="right" />
                    <EmptyHint style={{ padding: 8 }}>
                        (đã xóa)
                    </EmptyHint>
                </div>
            </div>
        );
    }

    return (
        <div className={`change-row kind-${kind}`}>
            <div className="change-cell left">
                <MetaRow change={change} side="left" />
                <ShapeTextChangesView change={change} side="left" />
            </div>

            <div className="change-cell right">
                <MetaRow change={change} side="right" />
                <ShapeTextChangesView change={change} side="right" />
            </div>
        </div>
    );
}

// ─────────────────────────────────────────────────────────────
// SECTION
// ─────────────────────────────────────────────────────────────
export function DiffSection({ section, onDeleteChange, onDeleteSubRow }) {
    const changes = section.changes || [];

    const fallbackHeading =
        (section.heading || '(No heading)')
            .split('>')
            .pop()
            .trim();

    const headingsDiffer = section.heading_changed;

    const leftHeading =
        headingsDiffer
            ? (section.left_heading || '(No heading)')
            : fallbackHeading;

    const rightHeading =
        headingsDiffer
            ? (section.right_heading || '(No heading)')
            : fallbackHeading;

    return (
        <div className="section-block">
            <div className="section-head">
                <div className="section-head-cell">{leftHeading}</div>
                <div className="section-head-cell">{rightHeading}</div>
            </div>
            <div className="col-labels">
                <div className="col-label">Original</div>
                <div className="col-label">Modified</div>
            </div>
            {changes.map(change => {
                const t = change.type || '';
                const deleteBtn = onDeleteChange
                    ? (
                        <DeleteRowBtn
                            onClick={() => onDeleteChange(section, change)}
                            icon="/delete_button.png"
                            title="Xóa thay đổi này"
                        />
                    )
                    : null;

                if (t.startsWith('image_'))
                    return (
                        <ChangeRowWrapper key={change.id} deleteBtn={deleteBtn}>
                            <div className={`change-row kind-${change.change_kind || 'replace'}`}>
                                <ImageChange change={change} />
                            </div>
                        </ChangeRowWrapper>
                    );

                if (t.startsWith('table_'))
                    return (
                        <ChangeRowWrapper key={change.id} deleteBtn={deleteBtn}>
                            <TableChange
                                change={change}
                                onDeleteSubRow={onDeleteSubRow
                                    ? (subIdx) => onDeleteSubRow(section, change, subIdx)
                                    : null
                                }
                            />
                        </ChangeRowWrapper>
                    );

                if (t.startsWith('shape_'))
                    return (
                        <ChangeRowWrapper key={change.id} deleteBtn={deleteBtn}>
                            <ShapeChangeRow change={change} />
                        </ChangeRowWrapper>
                    );

                if (t.startsWith('paragraph_') || t.startsWith('heading_'))
                    return (
                        <ChangeRowWrapper key={change.id} deleteBtn={deleteBtn}>
                            <TextChangeRow change={change} />
                        </ChangeRowWrapper>
                    );

                const lTxt =
                    change.left?.node?.content?.text_display
                    || change.left?.node?.content?.text
                    || change.left?.preview_text
                    || '';

                const rTxt =
                    change.right?.node?.content?.text_display
                    || change.right?.node?.content?.text
                    || change.right?.preview_text
                    || '';
                return (
                    <ChangeRowWrapper key={change.id} deleteBtn={deleteBtn}>
                        <div className={`change-row kind-${change.change_kind || 'replace'}`}>
                            <div className="change-cell left"><MetaRow change={change} /><div className="txt">{lTxt}</div></div>
                            <div className="change-cell right"><div className="meta-spacer" /><div className="txt">{rTxt}</div></div>
                        </div>
                    </ChangeRowWrapper>
                );
            })}
        </div>
    );
}

// ─────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────
function ChangeRowWrapper({ children, deleteBtn }) {
    return (
        <div className="change-row-wrapper">
            {children}
            {deleteBtn}
        </div>
    );
}

function DeleteRowBtn({
    onClick,
    icon = '/delete_button.png',
    title = 'Xóa'
}) {
    return (
        <button
            className="row-delete-btn"
            onClick={onClick}
            title={title}
            aria-label={title}
        >
            <img
                src={icon}
                alt={title}
                className="delete-icon"
            />
        </button>
    );
}